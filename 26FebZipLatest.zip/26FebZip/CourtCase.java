package cares.cwds.salesforce.pom.courts;

import java.util.ArrayList;
import static java.lang.String.format;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import cares.cwds.salesforce.constants.ModuleConstants;
import cares.cwds.salesforce.constants.SalesforceConstants;
import cares.cwds.salesforce.constants.ScreenConstants;
import cares.cwds.salesforce.utilities.common.TestRunSettings;
import cares.cwds.salesforce.utilities.common.Util;
import cares.cwds.salesforce.utilities.reports.common.ReportCommon;
import cares.cwds.salesforce.utilities.reports.extentmodel.PageDetails;
import cares.cwds.salesforce.utilities.reports.model.TestCaseParam;
import cares.cwds.salesforce.utilities.testng.TestNGCommon;
import cares.cwds.salesforce.utilities.web.CommonOperations;
import cares.cwds.salesforce.utilities.web.GenericLocators;
import cares.cwds.salesforce.utilities.web.SalesforceCommon;
import cares.cwds.salesforce.utilities.web.Webkeywords;

public class CourtCase {

	private WebDriver driver;
	ReportCommon exceptionDetails = new ReportCommon();
	Util util = new Util();
	GenericLocators genericLocators = null;
	TestNGCommon testngCommon = new TestNGCommon();
	TestCaseParam testCaseParam = (TestCaseParam) testngCommon.getTestAttribute("testCaseParam");
	String moduleName = ModuleConstants.COURTS;
	String screenName = ScreenConstants.COURTCASE;
	

public CourtCase(){ }
	
	public CourtCase(WebDriver wDriver)
	{
		initializePage(wDriver);
	}

	public void initializePage(WebDriver wDriver) 
    {
    	 driver = wDriver;
         PageFactory.initElements(driver, this);
         ReportCommon testStepLogDetails = new ReportCommon(); 
         testStepLogDetails.logModuleAndScreenDetails( moduleName, screenName);
         genericLocators = new GenericLocators(wDriver);
    }
	
	@FindBy(how = How.XPATH, using = "(//label[text()='Start Date']/../../following-sibling::lightning-input//input)[1]")
	public WebElement startDate;

	@FindBy(how = How.XPATH, using = "(//label[text()='End Date']/../../following-sibling::lightning-input//input)[1]")
	public WebElement endDate;


	@FindBy(how = How.XPATH, using = "(//label[text()='System Closed']/../../following-sibling::lightning-input//input)[1]")
	public WebElement systemClosed;
	
	@FindBy(how = How.XPATH, using = "//span[text()='Court Cases']//parent::span[@class='view-all-label']")
	public WebElement viewAllButton;
	
	@FindBy(how = How.XPATH, using = "//table[@aria-label='Warrants']//slot//slot//span")
	public WebElement warrent;
	
	@FindBy(how = How.XPATH, using = "//table[@aria-label='Hearings']//slot//slot//span")
	public WebElement hearing;
	
	@FindBy(how = How.XPATH, using = "(//p[text()='Status']//parent::div//slot//lightning-formatted-text)[2]")
	public WebElement caseStatus;
	
	@FindBy(how = How.XPATH, using = "(//slot[@name='primaryField']//lightning-formatted-text)[2]")
	public WebElement courtCaseID;
	
	String caseLink = "//span[text()='%s']";
	
	String recordLinks = "//table[@aria-label='%s']//slot//slot//span";

		
	public void navigateToCourtCase(String scriptIteration, String pomIteration){

		PageDetails action = new PageDetails();
		action.setPageActionName("Navigate to Court Case");
		action.setPageActionDescription("Navigate to Court Case");

		Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(), TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);

		Webkeywords.instance().click(driver, genericLocators.button(driver, "Court Record", testCaseDataSd.get("COURT_RECORD_EXPAND").get(0)), testCaseDataSd.get("COURT_RECORD_EXPAND").get(0),action);
		Webkeywords.instance().pauseDelay();
		Webkeywords.instance().click(driver, genericLocators.button(driver, "Court Case", testCaseDataSd.get("COURT_CASE").get(0)), testCaseDataSd.get("COURT_CASE").get(0),action);
     }
	
	
	public void courtCaseInformation(String scriptIteration, String pomIteration){

		PageDetails action = new PageDetails();
		action.setPageActionName("Court Case Information");
		action.setPageActionDescription("Court Case Information");

		Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(), TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
	
		String assignedSocialWorker = testCaseDataSd.get("ASSIGNED_SOCIAL_WORKER").get(0);	
		
		Webkeywords.instance().click(driver, genericLocators.button(driver, "New", testCaseDataSd.get("NEW_BTN").get(0)), testCaseDataSd.get("NEW_BTN").get(0),action);
		Webkeywords.instance().pause();
		
		Webkeywords.instance().setText(driver,
				genericLocators.textbox(driver, "Dependency Court Case Number", testCaseDataSd.get("DEPENDENCY_COURT_CASE_NUMBER").get(0)),
				util.getRandom(testCaseDataSd.get("DEPENDENCY_COURT_CASE_NUMBER").get(0)), action);
		Webkeywords.instance().setText(driver,
				genericLocators.textbox(driver, "Attorney Name", testCaseDataSd.get("ATTORNEY_NAME").get(0)),
				util.getRandom(testCaseDataSd.get("ATTORNEY_NAME").get(0)), action);
		Webkeywords.instance().setText(driver,
				genericLocators.textbox(driver, "Dellnquency Court Case Number", testCaseDataSd.get("DELLNQUENCY_COURT_CASE_NUMBER").get(0)),
				util.getRandom(testCaseDataSd.get("DELLNQUENCY_COURT_CASE_NUMBER").get(0)), action);
		Webkeywords.instance().setText(driver,
				genericLocators.textbox(driver, "Reason to Reopen", testCaseDataSd.get("REASON_TO_REOPEN").get(0)),
				util.getRandom(testCaseDataSd.get("REASON_TO_REOPEN").get(0)), action);

		Webkeywords.instance().selectValueInSearchbox(driver, "Assigned Social Worker", assignedSocialWorker, action);
		Webkeywords.instance().selectValueInputDropdown(driver, testCaseDataSd.get("CONTACT_METHOD").get(0),"Contact Method", action);
		Webkeywords.instance().selectValueInputDropdown(driver, testCaseDataSd.get("STATUS").get(0),"Status", action);
		
	
		Webkeywords.instance().setDateText(driver, startDate, CommonOperations.getDate("M/d/yyyy", testCaseDataSd.get("START_DATE").get(0)), action);		
		Webkeywords.instance().setDateText(driver, endDate, CommonOperations.getDate("M/d/yyyy", testCaseDataSd.get("END_DATE").get(0)), action);		
		Webkeywords.instance().setDateText(driver, systemClosed, CommonOperations.getDate("M/d/yyyy", testCaseDataSd.get("SYSTEM_CLOSED").get(0)), action);		
		Webkeywords.instance().scrollToBottom(driver);
		Webkeywords.instance().pauseDelay();
		Webkeywords.instance().click(driver, genericLocators.button(driver, "Save",testCaseDataSd.get("SAVE_BTN").get(0)),testCaseDataSd.get("SAVE_BTN").get(0),action);
		if(!(testCaseDataSd.get("VERIFY_ISSUE_TOAST_MESSAGE").get(0)).equalsIgnoreCase("n/a"))
			SalesforceCommon.verifyToastMessage(driver, "Please close the open warrant(s) in order to close the Court Case.", action );
		if(!(testCaseDataSd.get("VERIFY_ISSUE_TOAST_MESSAGE2").get(0)).equalsIgnoreCase("n/a"))
			SalesforceCommon.verifyToastMessage(driver, "Please vacate the future hearing(s) prior to closing the Court Case.", action );
		if(!(testCaseDataSd.get("VERIFY_SUCCESS_TOAST_MESSAGE").get(0)).equalsIgnoreCase("n/a"))
			SalesforceCommon.verifyToastMessage(driver, "Data saved successfully.", action );
		Webkeywords.instance().pause();
		
     	SalesforceConstants.setConstantValue("COURT_CASE_ID"+pomIteration, courtCaseID.getText());
	
	}
	
	public void navigateToCourtCaseRecord(String scriptIteration, String pomIteration){
		PageDetails action = new PageDetails();
		action.setPageActionName("Navigate to court case record");
		action.setPageActionDescription("Navigate to court case record");
		
		Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(), TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
		
		String caseId = SalesforceConstants.getConstantValue(testCaseDataSd.get("COURT_CASE_ID").get(0));
		Webkeywords.instance().scrollIntoViewElement(driver, viewAllButton);
		Webkeywords.instance().click(driver, viewAllButton, testCaseDataSd.get("VIEWALL").get(0), action);
		Webkeywords.instance().refreshPage(driver);
		Webkeywords.instance().pause();
		String formatedXpath = format(caseLink,caseId);
		WebElement caseIdXpath = driver.findElement(By.xpath(formatedXpath));
		Webkeywords.instance().waitElementClickable(driver, caseIdXpath);
		Webkeywords.instance().jsClick(driver,  caseIdXpath, testCaseDataSd.get("COURT_CASE_ID").get(0),action);
		Webkeywords.instance().pause();	
	}
	
	public void verifyRecordsLinked(String scriptIteration, String pomIteration)  {
		PageDetails action = new PageDetails();
		
		action.setPageActionName("Verify Records are linked to Court Case");
		action.setPageActionDescription("Verify Records are linked to Court Case");
		
		Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(), TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);

		Webkeywords.instance().waitElementClickable(driver, genericLocators.button(driver, "Related", testCaseDataSd.get("RELATED_TAB").get(0)));
		Webkeywords.instance().click(driver, genericLocators.button(driver, "Related", testCaseDataSd.get("RELATED_TAB").get(0)), testCaseDataSd.get("RELATED_TAB").get(0),action);
		
		
		String expectedWarrentID = SalesforceConstants.getConstantValue("WARRENT_ID");
		String actualWarrentID = warrent.getText();
		Webkeywords.instance().softAssertText(actualWarrentID, expectedWarrentID);
		Webkeywords.instance().scrollToBottom(driver); 
		String expectedHearingID = SalesforceConstants.getConstantValue("HEARING_ID"+pomIteration);
		String actualHearingID = hearing.getText();
		 Webkeywords.instance().softAssertText(actualHearingID, expectedHearingID);			
	}
	
	public void navigateToDetailsTab(String scriptIteration, String pomIteration)  {
		PageDetails action = new PageDetails();
		
		action.setPageActionName("Navigate to Court Case Details Tab");
		action.setPageActionDescription("Navigate to Court Case Details Tab");
		
		Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(), TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
		Webkeywords.instance().scrollUpPageToTheTop(driver);
		Webkeywords.instance().click(driver, genericLocators.button(driver, "Details", testCaseDataSd.get("DETAILS_TAB").get(0)), testCaseDataSd.get("DETAILS_TAB").get(0),action);		
	}
	
	public void verifyCourtCaseStatus()  {
		PageDetails action = new PageDetails();
		
		action.setPageActionName("Verify Court case status after case is closed");
		action.setPageActionDescription("Verify Court case status after case is closed");
		
		Webkeywords.instance().pause();
		String expectedStatus = "Closed";
		String actualStatus = caseStatus.getText();
		Webkeywords.instance().softAssertText(actualStatus, expectedStatus);

	}
}
