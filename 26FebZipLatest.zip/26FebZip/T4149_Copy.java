package uitests.testng.milestone15;

import java.awt.AWTException;
import java.lang.reflect.Method;
import java.util.Objects;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import cares.cwds.salesforce.constants.SalesforceConstants;
import cares.cwds.salesforce.pom.Home;
import cares.cwds.salesforce.pom.Login;
import cares.cwds.salesforce.pom.courts.CourtCase;
import cares.cwds.salesforce.pom.courts.CourtHearings;
import cares.cwds.salesforce.pom.courts.CourtMinuteOrder;
import cares.cwds.salesforce.pom.courts.CourtOfficerNotes;
import cares.cwds.salesforce.pom.courts.CourtReports;
import cares.cwds.salesforce.pom.courts.CourtWorkItems;
import cares.cwds.salesforce.pom.courts.DocumentDistributions;
import cares.cwds.salesforce.pom.courts.Participants;
import cares.cwds.salesforce.pom.courts.Related;
import cares.cwds.salesforce.pom.person.PersonAddresses;
import cares.cwds.salesforce.pom.referral.Person;
import cares.cwds.salesforce.pom.referral.ReleasesOfInformationAndConsentForm;
import cares.cwds.salesforce.pom.referralcase.CaseReferralPersons;
import cares.cwds.salesforce.pom.referralcase.placement.ChildLocations;
import cares.cwds.salesforce.pom.referralcase.placement.LegalAuthority;
import cares.cwds.salesforce.pom.referralcase.placement.Placement;
import cares.cwds.salesforce.pom.referralcase.placement.ProviderSearch;
import cares.cwds.salesforce.pom.referralcase.placement.Removal;
import cares.cwds.salesforce.utilities.testng.TestNGCommon;
import cares.cwds.salesforce.utilities.testng.TestNGListener;
import cares.cwds.salesforce.utilities.web.SalesforceCommon;
import uitests.testng.datasetup.CaseDataSetup1;


/*****
 * Traceability*************
 * CARESV1-233 Courts: File Documents & Send to Parties
 * 
 * CARESV1-230 Courts: Document Court Notes in CWS-CARES
 * 
 * CARESV1-229 Courts: Receive & Record Court Results and Orders in CWS-CARES
 * 
 * CARESV1-216 Courts: Create Court Report
 * 
 * CARESV1-180 Courts: Calendar Request
 * 
 * CARESV1-148 Courts: Document Detention Hearing Notice
 *
 */

/*****
 * Created By: SIT PaaS Automation Team

 * Created Date:01/17/2025

 * Modified By: SIT PaaS Automation Team

 * Modified Date:02/21/2025
 * 
 */

@Listeners(TestNGListener.class)
public class T4149  extends TestNGCommon{
	String testCaseName = "T4149_Court Hearing Framework_Verify users should be able to document Court Officer Notes in hearing.";
	String moduleName = "cares";
	String fileName = "ScriptMasterSheet"; 
	private static final String Petition_Title ="Findings and Orders/Minute order received"; 
	private static final String Jurisdiction_Message ="Findings and Orders/Minute Orders have been received for terminated jurisdiction"; 

	@BeforeMethod
	public void setUpReport()
	{
		setTestAttributes("testCaseParam",testCaseParam);
	}

	@Test (dataProvider = "data-provider",priority = 1, enabled = true)
	public void testT4149(String scriptIteration) throws AWTException, InterruptedException{
		driver = (WebDriver) getTestAttribute("driver");

		/** PreReq Data ***/
		//Read Investigative Case record from data sheet
		SalesforceConstants.setConstantValue("CASE_ID1","CAS-000001584525"/*readOutputSheet("Case", false, "Contra")*/);

		//Running preData setup scenario if case record is null from output data sheet
		if(Objects.isNull(SalesforceConstants.getConstantValue("CASE_ID1")) ){
			testCaseParam.setTestNGTestMethodName("testCaseDataSetup1");
			CaseDataSetup1 caseDataSetup = new CaseDataSetup1();
			caseDataSetup.testCaseDataSetup1("1");
			testCaseParam.setTestNGTestMethodName("testT4149");
		}

		///////////////////////// Login As CM Worker County 1/////////////////////////////////////////////////////
		
		Login login = new Login(driver);
		login.processLoginNew( scriptIteration,SalesforceConstants.POMITERATION1, SalesforceConstants.LOGINUSER); 
 
		Home home = new Home(driver);
		home.closeAllTabs();
		home.navigateToAppMenuPage("CARES Items", scriptIteration, SalesforceConstants.POMITERATION1);
		home.searchConstantMethod("Case", scriptIteration, SalesforceConstants.POMITERATION1);
		
		//add 1 person , 1 legal guarding
		Person folioPerson = new Person(driver);
		SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.CASEURL);
		SalesforceCommon.scrollDown(driver);
		folioPerson.navigateToFolioPersonsTab( scriptIteration, SalesforceConstants.POMITERATION1);
		folioPerson.addFolioPerson( scriptIteration, SalesforceConstants.POMITERATION1);
		SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.CASEURL);

		CaseReferralPersons caseReferralPersons = new CaseReferralPersons(driver);
		caseReferralPersons.navigateToInvCaseFolioPersons(scriptIteration, SalesforceConstants.POMITERATION1);
		caseReferralPersons.getCaseFolioPersonDetails();

		String focusChildName= SalesforceConstants.getObjectValue("CASE_PERSON_MAP").get("FocusChild1")[1];
		String victim= SalesforceConstants.getObjectValue("CASE_PERSON_MAP").get("Victim1")[1];
		caseReferralPersons.navigateToCaseFolioPersonName(focusChildName,scriptIteration, SalesforceConstants.POMITERATION1);

		PersonAddresses personAddress = new PersonAddresses(driver);
		personAddress.navigateToAddressesTab(scriptIteration, SalesforceConstants.POMITERATION1);
		personAddress.addPersonAddress(scriptIteration,SalesforceConstants.POMITERATION1);
		SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.CASEURL);

		caseReferralPersons.navigateToInvCaseFolioPersons(scriptIteration, SalesforceConstants.POMITERATION1);
		caseReferralPersons.navigateToCaseFolioPersonName(victim,scriptIteration, SalesforceConstants.POMITERATION1);

		personAddress.navigateToAddressesTab(scriptIteration, SalesforceConstants.POMITERATION1);
		personAddress.addPersonAddress(scriptIteration,SalesforceConstants.POMITERATION1);
		SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.CASEURL);

//		SalesforceConstants.setConstantValue("folioPersonName1", "AUTONgoc AUTOVicenta");
//		SalesforceConstants.setConstantValue("ProviderOption_ID1","POP-000000422125");
//		SalesforceConstants.setConstantValue("PLACEMENT_NAME1", "AUTOCXXHNRCLIZ");
//		SalesforceConstants.setConstantValue("Removal_ID1","REM-000000210625");
//		SalesforceConstants.setConstantValue("CLO_ID1","CLO-000000592425");	
//		SalesforceConstants.setConstantValue("COURT_CASE_ID1","CCS-000000078025");
//		SalesforceConstants.setConstantValue("HEARING_ID1","CWI-000000573225");

		ProviderSearch providerSearch = new ProviderSearch(driver);
		providerSearch.navigateToProviderSearch(scriptIteration,SalesforceConstants.POMITERATION1);
		providerSearch.searchProvderType(scriptIteration,SalesforceConstants.POMITERATION1);
		providerSearch.enterNewPlacementDetails(scriptIteration,SalesforceConstants.POMITERATION1);

		SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.CASEURL);
		Placement placement = new Placement(driver);
		placement.navigateToPlacement(scriptIteration, SalesforceConstants.POMITERATION1);

		Removal removal = new Removal(driver);
		removal.navigateToRemovalTab(scriptIteration, SalesforceConstants.POMITERATION1);
		removal.addRemovalDetails(scriptIteration, SalesforceConstants.POMITERATION1);

		placement.navigateToPlacement(scriptIteration, SalesforceConstants.POMITERATION1);
		ChildLocations childLocations = new ChildLocations(driver);
		childLocations.clickNewChildLocationType(scriptIteration, SalesforceConstants.POMITERATION1);
		childLocations.enterChildLocationPlacementDetails(scriptIteration, SalesforceConstants.POMITERATION1);
		
		SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.CASEURL);
		home.searchConstantMethod("Case", scriptIteration, SalesforceConstants.POMITERATION1);
	    
		CourtCase courtCase = new CourtCase(driver);
		courtCase.navigateToCourtCase(scriptIteration, SalesforceConstants.POMITERATION1);
		courtCase.courtCaseInformation(scriptIteration, SalesforceConstants.POMITERATION1);
		SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.CASEURL);

		courtCase.navigateToCourtCase(scriptIteration, SalesforceConstants.POMITERATION1);
		courtCase.navigateToCourtCaseRecord(scriptIteration, SalesforceConstants.POMITERATION2);
		SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.CASEURL);

		CourtWorkItems courtWorkItem = new CourtWorkItems(driver);
		courtWorkItem.navigateToCourtWorkItems(scriptIteration, SalesforceConstants.POMITERATION1);
		courtWorkItem.verifyCourtWorkItemsRelatedList(scriptIteration, SalesforceConstants.POMITERATION1);

		CourtHearings hearing = new CourtHearings(driver);
		hearing.enterHearingDetails(scriptIteration, SalesforceConstants.POMITERATION1);
		
		Participants participants = new Participants(driver);
		participants.navigateToParticipants(scriptIteration, SalesforceConstants.POMITERATION1);
		participants.verifyParticipantsRelatedList(scriptIteration, SalesforceConstants.POMITERATION2);
		participants.addFocusChild(scriptIteration, SalesforceConstants.POMITERATION2);
		SalesforceConstants.getCurrentPageUrl(driver,"HEARINGCOURTWORKITEM");

		participants.navigateToParticipants(scriptIteration, SalesforceConstants.POMITERATION1);
		participants.verifyHeaderColumnsInParticipantsForChildren(scriptIteration, SalesforceConstants.POMITERATION2);
		participants.addPickParticipant(scriptIteration, SalesforceConstants.POMITERATION2);
		participants.verifyHeaderColumnsInParticipantsForWorkItem(scriptIteration, SalesforceConstants.POMITERATION2);
		SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.CASEURL);

		courtWorkItem = new CourtWorkItems(driver);
		courtWorkItem.navigateToCourtWorkItems(scriptIteration, SalesforceConstants.POMITERATION1);

		hearing = new CourtHearings(driver);
		hearing.navigateToHearingRecord(scriptIteration, SalesforceConstants.POMITERATION1);
		hearing.verifySectionsInHearingDetails(scriptIteration, SalesforceConstants.POMITERATION1);

		CourtMinuteOrder courtMinuteOrder = new CourtMinuteOrder(driver);
		courtMinuteOrder.navigateToCourtMinuteOrder(scriptIteration, SalesforceConstants.POMITERATION1);
		courtMinuteOrder.validateNewBtn();

		hearing = new CourtHearings(driver);
		hearing.navigateToHearingDetailTab(scriptIteration, SalesforceConstants.POMITERATION2);
		hearing.editHearingRecord(scriptIteration, SalesforceConstants.POMITERATION2);
		SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.HEARINGCOURTWORKITEMURL);
	
		hearing.navigateToHearingDetailTab(scriptIteration, SalesforceConstants.POMITERATION2);
		hearing.editHearingRecord(scriptIteration, SalesforceConstants.POMITERATION3);

		courtMinuteOrder = new CourtMinuteOrder(driver);
		courtMinuteOrder.navigateToCourtMinuteOrder(scriptIteration, SalesforceConstants.POMITERATION1);
		courtMinuteOrder.validateNewBtn();

		courtMinuteOrder.navigateToCourtMinuteOrderPage(scriptIteration, SalesforceConstants.POMITERATION1);
		courtMinuteOrder.addCourtMinuteOrderPageInformation(scriptIteration, SalesforceConstants.POMITERATION1);
		courtMinuteOrder.getCourtMiniteOrderID(scriptIteration, SalesforceConstants.POMITERATION1);
		
		home = new Home(driver);
	    String name = SalesforceConstants.getObjectValue("CASE_PERSON_MAP").get("Victim1")[1];
	    String cwiID = 	SalesforceConstants.getConstantValue("HEARING_ID1");
		home.verifyCourtNotification(Petition_Title,"Findings and Orders/Minute Orders have been received for petition null for following children that is available on " + cwiID + " for : " + name.replace(" ","  "));

		SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.HEARINGCOURTWORKITEMURL);
		courtMinuteOrder.navigateToCourtMinuteOrder(scriptIteration, SalesforceConstants.POMITERATION1);
		courtMinuteOrder.navigateToExistingCourtMinuteOrderRecord(scriptIteration, SalesforceConstants.POMITERATION2);
     	courtMinuteOrder.addCourtMinuteOrderPageInformation(scriptIteration, SalesforceConstants.POMITERATION2);
	
	
	}

	@Test (dataProvider = "data-provider")
	public void testT4149_1(String scriptIteration) throws AWTException, InterruptedException{
		driver = (WebDriver) getTestAttribute("driver");
		
		Login login = new Login(driver);
		login.processLoginNew( scriptIteration,SalesforceConstants.POMITERATION1, SalesforceConstants.LOGINUSER); 
 
		Home home = new Home(driver);
		home.closeAllTabs();
		home.navigateToAppMenuPage("CARES Items", scriptIteration, SalesforceConstants.POMITERATION1);
		home.searchConstantMethod("Case", scriptIteration, SalesforceConstants.POMITERATION1);
				
		// Step 42-43 
		SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.CASEURL);
		Placement placement = new Placement(driver);
		placement.navigateToPlacement(scriptIteration, SalesforceConstants.POMITERATION1);

		Removal removal = new Removal(driver);
		removal.navigateToRemovalTab(scriptIteration, SalesforceConstants.POMITERATION1);
		removal.navigateToRemovalRecord(scriptIteration, SalesforceConstants.POMITERATION1);

		LegalAuthority legalAuthority = new LegalAuthority(driver);
		legalAuthority.navigateToLegalAuthorityTab(scriptIteration,SalesforceConstants.POMITERATION1);
		legalAuthority.clickNewLegalAuthority(scriptIteration,SalesforceConstants.POMITERATION1);
		legalAuthority.addLegalInfo(scriptIteration,SalesforceConstants.POMITERATION1);
		legalAuthority.verifyingLegalAuthorityHeaders(scriptIteration,SalesforceConstants.POMITERATION1);

		//Step 44
		//legalAuthority.clickNewLegalAuthority(scriptIteration,SalesforceConstants.POMITERATION1);
		//legalAuthority.addLegalInfo(scriptIteration,SalesforceConstants.POMITERATION1);

		//Step 45-46
		SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.HEARINGCOURTWORKITEMURL);
		CourtMinuteOrder courtMinuteOrder = new CourtMinuteOrder(driver);
		courtMinuteOrder.navigateToExistingCourtMinuteOrderRecord(scriptIteration,SalesforceConstants.POMITERATION3);
		courtMinuteOrder.addCourtMinuteOrderPageInformation(scriptIteration,SalesforceConstants.POMITERATION3);
		SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.HEARINGCOURTWORKITEMURL);

		//Step 48
		//		Related related = new Related(driver);
		//		related.navigateToRelatedTab(scriptIteration,SalesforceConstants.POMITERATION1);
		//		related.navigateToExistingRelatedFolioRecord(scriptIteration,SalesforceConstants.POMITERATION1);
		//
		//		//Steps 49-50
		//		SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.CASEURL);			
		//		placement= new Placement(driver);
		//		placement.navigateToPlacement(scriptIteration, SalesforceConstants.POMITERATION1);
		//
		//		childLocations = new ChildLocations(driver);
		//		childLocations.navigateToChildLocationTab(scriptIteration, SalesforceConstants.POMITERATION2);
		//		childLocations.navigateToChildLocationRecord(scriptIteration, SalesforceConstants.POMITERATION2);
		//		childLocations.navigateToChildLocationRecord(scriptIteration, SalesforceConstants.POMITERATION2);
		//
		//Steps 51- 52- 53 - Link not available in new UI, 48 to 53 not applicable need query to run.

		//Step 54
		SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.CASEURL);
		CourtWorkItems courtWorkItems = new CourtWorkItems(driver);
		courtWorkItems.navigateToCourtWorkItems(scriptIteration, SalesforceConstants.POMITERATION2);

		//Step 55
		CourtHearings hearing = new CourtHearings(driver);
		hearing.navigateToHearingRecord(scriptIteration, SalesforceConstants.POMITERATION4);

		//Step 56-57
		CourtOfficerNotes courtOfficerNotes = new CourtOfficerNotes(driver);
		courtOfficerNotes.navigateToCourtOfficerNotes(scriptIteration, SalesforceConstants.POMITERATION1);
		courtOfficerNotes.addCourtOfficerNotesPageDetails(scriptIteration, SalesforceConstants.POMITERATION1);

		//Step 58-62-63-64-65-66 
		DocumentDistributions documentDistributions = new DocumentDistributions(driver);
		documentDistributions.navigateToDocumentDistributions(scriptIteration, SalesforceConstants.POMITERATION1);    
		documentDistributions.addDistributionType(scriptIteration, SalesforceConstants.POMITERATION1);
		documentDistributions.addCourtDocumentsInformation(scriptIteration, SalesforceConstants.POMITERATION1);

		documentDistributions.navigateToDocumentDistributions(scriptIteration, SalesforceConstants.POMITERATION1);
		documentDistributions.addDistributionType(scriptIteration, SalesforceConstants.POMITERATION2);
		documentDistributions.addNoticeInformation(scriptIteration, SalesforceConstants.POMITERATION2);

		//Step 67
		documentDistributions.navigateToDocumentDistributions(scriptIteration, SalesforceConstants.POMITERATION1);
		documentDistributions.navigateToNoticeRecord(scriptIteration, SalesforceConstants.POMITERATION2);
		documentDistributions.verfiyNoticeRecord(scriptIteration, SalesforceConstants.POMITERATION2);

		//Step 68  > District Attorny Page is getting freeze ---- Defect logged
		//        SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.HEARINGCOURTWORKITEMURL);
		//
		//        documentDistributions.navigateToDocumentDistributions(scriptIteration, SalesforceConstants.POMITERATION1);
		//        documentDistributions.addDistributionType(scriptIteration, SalesforceConstants.POMITERATION1);
		//        documentDistributions.addNoticeInformation(scriptIteration, SalesforceConstants.POMITERATION1);
		//          
		//        SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.HEARINGCOURTWORKITEMURL);
		//
		//        documentDistributions.navigateToNoticeRecord(scriptIteration, SalesforceConstants.POMITERATION1);
		//        documentDistributions.verfiyNoticeRecord(scriptIteration, SalesforceConstants.POMITERATION1);

		//Step 69  
		SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.HEARINGCOURTWORKITEMURL);

		documentDistributions.navigateToDocumentDistributions(scriptIteration, SalesforceConstants.POMITERATION4); 
		documentDistributions.addDistributionType(scriptIteration, SalesforceConstants.POMITERATION4);
		documentDistributions.addNoticeInformation(scriptIteration, SalesforceConstants.POMITERATION4);

		documentDistributions.navigateToDocumentDistributions(scriptIteration, SalesforceConstants.POMITERATION4); 
		documentDistributions.navigateToNoticeRecord(scriptIteration, SalesforceConstants.POMITERATION4);
		documentDistributions.verfiyNoticeRecord(scriptIteration, SalesforceConstants.POMITERATION4);

		//Step 70 
		SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.HEARINGCOURTWORKITEMURL);

		documentDistributions.navigateToDocumentDistributions(scriptIteration, SalesforceConstants.POMITERATION5); 
		documentDistributions.addDistributionType(scriptIteration, SalesforceConstants.POMITERATION5);
		documentDistributions.addNoticeInformation(scriptIteration, SalesforceConstants.POMITERATION5);

		documentDistributions.navigateToDocumentDistributions(scriptIteration, SalesforceConstants.POMITERATION5); 
		documentDistributions.navigateToNoticeRecord(scriptIteration, SalesforceConstants.POMITERATION5);
		documentDistributions.verfiyNoticeRecord(scriptIteration, SalesforceConstants.POMITERATION5);

	}
	@Test (dataProvider = "data-provider")
	public void testT4149_2(String scriptIteration) throws AWTException, InterruptedException{

		//login
		
		//search
		
		//Step 71       
		SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.HEARINGCOURTWORKITEMURL);
		CourtHearings hearing = new CourtHearings(driver);
		hearing.navigateToHearingDetailTab(scriptIteration, SalesforceConstants.POMITERATION5);
		hearing.verifySectionsInHearingDetails(scriptIteration, SalesforceConstants.POMITERATION5);

		//Step 72-75
		SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.HEARINGCOURTWORKITEMURL);
		CourtReports courtReports = new CourtReports(driver);
		courtReports.navigateToCourtReports(scriptIteration, SalesforceConstants.POMITERATION1);
		courtReports.addCourtReportPageInformation(scriptIteration, SalesforceConstants.POMITERATION1);

		//Step 76-79 ----- defect logged
		//      SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.CASEURL);
		//      ReleasesOfInformationAndConsentForm releasesOfInformationAndConsentForm = new ReleasesOfInformationAndConsentForm(driver);
		//      releasesOfInformationAndConsentForm.navigateToReleaseOfInformationAndConsentForm(scriptIteration, SalesforceConstants.POMITERATION1);
		//      releasesOfInformationAndConsentForm.addReleaseOfInformationAndConsentFormDetails(scriptIteration, SalesforceConstants.POMITERATION1); 
		//     
		//      SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.CASEURL);
		//      releasesOfInformationAndConsentForm.navigateToReleaseOfInformationAndConsentForm(scriptIteration, SalesforceConstants.POMITERATION1);
		//      releasesOfInformationAndConsentForm.navigateToReleaseInformationAndConsentFormRecord(scriptIteration, SalesforceConstants.POMITERATION1);
		//      releasesOfInformationAndConsentForm.verfiyReleaseInformationAndConsentForm(scriptIteration, SalesforceConstants.POMITERATION1);

	}

	@DataProvider (name = "data-provider")
	public String[] dpMethod(Method method){
		testCaseParam.setTestCaseName(testCaseName);
		testCaseParam.setModuleName(moduleName);
		testCaseParam.setBrowser(browser);
		testCaseParam.setTestCaseDescription(testCaseParam.getTestCaseName());
		testCaseParam.setTestCaseDescription(testCaseParam.getTestCaseName());
		testCaseParam.setTestNGTestMethodName(method.getName());
		return setScriptIterationFlag(fileName,moduleName, method.getName());

	}
}
