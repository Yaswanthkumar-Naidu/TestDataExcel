
package cares.cwds.salesforce.constants;

public class ScreenConstants {	
	
	private ScreenConstants() {
		
	}
	/********************************Service*************************************/
	public static final String SERVICESCATEGORY = "ServicesCategory";
	public static final String SERVICESNAMEEBP = "ServiceNameEBP";
	public static final String SERVICETYPE = "ServiceType";
	/********************************Common*************************************/
	public static final String LOGIN = "Login";
	public static final String HOME = "Home";
	public static final String HEADERSPAGE = "Header";
	public static final String LOGOUT = "Logout";
	public static final String APPROVALAUDITHISTORY = "ApprovalAuditHistory";
	public static final String ORGANIZATIONS = "Organization";
	public static final String ADDRESSES = "Addresses";
	public static final String LOCATION = "Location";
	public static final String RELATEDPERSONS = "RelatedPersons";
	public static final String CORRESPONDENCES = "Correspondences";
	public static final String RECALLANDRESUBMIT = "RecallAndResubmitRecord";
	/*******************************Screening************************************/
	public static final String SCREENINGHEADER = "ScreeningsHeader";
	public static final String SCREENINGSPAGE = "ScreeningsPage";
	public static final String SCREENINGDETAILS = "ScreeningDetails";
	public static final String SCREENINGHISTORY = "ScreeningHistory";
	public static final String SCREENINGDOCUMENTS = "ScreeningDocuments";
	public static final String SAFELYSURRENDEREDBABY = "ScreeningSafelySurrenderedBaby";
	public static final String SCREENINGPERSONS = "ScreeningPersons";
	public static final String SCREENINGVALIDATEPERSON = "ScreeningValidatePerson";
	public static final String SCREENINGADDRESSES = "ScreeningAddresses";
	public static final String CALLBACKATTEMPTS = "ScreeningCallBackAttempts";
	public static final String SCREENINGALLEGATIONS = "ScreeningAllegations";
	public static final String SCREENINGSAFETYALERTS = "ScreeningSafetyAlerts";
	public static final String SCREENINGASSESSMENTS = "ScreeningAssessments";
	public static final String SCRTRIBALINQUIRYANDCOLLABORATION = "ScreeningTribalInquiry";
	public static final String SCREENINGCONTACTLOG = "ScreeningContactLog";
	public static final String SCREENINGERR = "ScreeningERR";
	public static final String SUPERVISORREVIEWPROMOTION = "ScreeningSupervisorReview";
	public static final String SCREENINGSUBMITFORAPPROVAL = "ScreeningSubmitForApproval";
	public static final String SCREENINGAPPROVAL = "ScreeningApproval";
	/*******************************Referral************************************/	
	public static final String ALLIGATIONS = "Allegations";
	public static final String DISPOSITION = "Disposition";
	public static final String COMMERCIALSEXUALEXPLOITATION = "CommercialSexualExploite";
	public static final String FATALITYNEARFATALITY = "FatalityNearFatality";
	public static final String ADMINISTRATIVEHEARINGS = "AdministrativeHearings";
	public static final String DETAILS = "Details";
	public static final String ASSIGNMENTS = "Assignments";
	public static final String CORRESPONDENCE = "Correspondence";
	public static final String HISTORY = "RefHistory";
	public static final String SCREENINGREVIEW = "ScreeningReview";
	public static final String TRIBALINQUIRYANDCOLLABORATION = "TribalInquiry";
	public static final String CONTACTLOG = "ContactLog";
	public static final String DOCUMENTS = "Documents";
	public static final String APPROVALANDAUDITHISTORY = "ApprovalAndAuditHistory";
	public static final String RELATEDREFERRALS = "RelatedReferrals";
	public static final String SCREENINGSINREFERRAL = "ScreeningsInReferral";
	public static final String ATTORNEYCLIENTLOG = "AttorneyClientLog";
	public static final String SUBMITFORAPPROVAL = "SubmitForApproval";
	public static final String CHANGEASSIGNMENTS = "ChangeAssignments";
	public static final String PERSONS = "Person";
	public static final String VALIDATEPERSON ="ValidatePerson";
	public static final String ADDENDUMS ="Addendums";
	public static final String NEWCASE ="NewCase";
	public static final String SERVICECOMPONENTS ="ServiceComponents";
	public static final String RELEASESOFINFORMATIONANDCONSENTFORM ="ReleasesOfInformation";
	public static final String VISITLOGS ="VisitLogs";
	public static final String LOCATIONSERVICESORG = "LocationServicesOrg";
	public static final String CREDENTIALSORG = "CredentialsOrg";
	public static final String SPECIALIZATIONORG = "SpecializationsOrg";
	public static final String ERR = "ERR";
	public static final String FINDAWORKER = "FindAWorker";
	public static final String NEWITEMSERVICEEEQUEST = "";
	public static final String VISITATIONDETERMINATIONS = "VisitationDeterminations";
	public static final String LEGALAUTHORITY ="LegalAuthority";
	public static final String SPECIALIZATION ="Specialization";
	public static final String INSPECTIONS = "Inspections";
	public static final String PROMOTETOCASE = "PromoteToCase";
	public static final String RECORDALERTSANDTASKS = "RecordAlertsAndTasks";
	public static final String CASECLOSURE ="CaseClosure";
	/*******************************CASE************************************/
	public static final String NEWNONINVESTIGATIVECASE = "NewNonInvestigativeCase";
	public static final String CASEASSIGNMENTS = "CaseAssignments";
	public static final String CASECHANGEASSIGNMENTS = "CaseChangeAssignments";
	public static final String CASETASK = "CaseTask";
	public static final String CASEDETAILS = "CaseDetails";
	public static final String CASESUBMITFORAPPROVAL = "CaseSubmitForApproval";
	public static final String CASEAPPROVALHISTORY = "CaseApprovalHistory";
	public static final String CASERELATEDREFERRALS = "CaseRelatedReferrals";
	public static final String CASEREFERRALPERSONS = "CaseReferralPersons";
	public static final String CASETRIBALINQUIRYANDCOLLABORATION = "CaseTribalInquiry";
	public static final String CASECONTACTLOG = "CaseContactLog";
	public static final String CASEFAMILYTRANSFER = "CaseFamilyTransfer";
	public static final String CASETYPE = "CaseType";
	public static final String CASESTOTRANSFER ="CasesToTransfer";
	public static final String FAMILYTRANSFERRECORD = "FamilyTransferRecord";
	/*******************************Placement************************************/
	public static final String BACKGROUNDCHECKS = "BackgroundChecks";
	public static final String PROVIDERSEARCH = "ProviderSearch";
	public static final String PROVIDEROPTIONS = "ProviderOptions";
	public static final String CHILDLOCATIONCORRESPONDENCES ="ChildLocationCorrespondences";
	public static final String ESIGN = "Esign";
	public static final String CHILDLOCATIONABSENCES ="ChildLocationAbsences";
	public static final String CHILDLOCATIONAUDITHISTORY ="ChildLocationAuditHistory";
	public static final String CHILDLOCATIONCONTACTLOGS ="ChildLocationContactLogs";
	public static final String CHILDLOCATIONOVERSTAYREPORTS="ChildLocationOverstayRepo";
	public static final String CHILDLOCATIONRATES ="ChildLocationRates";
	public static final String CHILDLOCATIONS ="ChildLocations";
	public static final String PLACEMENT ="Placement";
	public static final String PLACEMENTNEEDS ="PlacementNeeds";
	public static final String TRIBEPLACEMENTPREFERENCES ="TribePlacementPreferences";
	public static final String PARENTGUARDAIANPLACEMENTPREFERENCE = "ParentGuardianPlacementPreferences";
	public static final String PLACEMENTPRESERVATIONSTRATEGY ="PlacementPreservationStrategy";
	public static final String PLACEMENTSTABILITY ="PlacementStability";
	public static final String PROVIDEROPTIONSDOCUMENTS ="ProviderOptionsDocuments";
	public static final String REMOVAL ="Removal";
	public static final String TRIBALPLACEMENTPREFERENCE= "TribalPlacementPreferences";
	public static final String YOUTHPLACEMENTPREFERENCE= "YouthPlacementPreferences";
	public static final String ELIGIBILITYDETAILS= "EligibilityDetails";
	public static final String CHILDSUPPORTELIGIBILITYINFO= "ChildSupportEligibilityInfo";
	public static final String MEDICALELIGIBILITYREQUESTINFO= "MediCalEligibilityRequestInfo";
	public static final String QUALIFIEDRESIDENTIALTREATMENT= "QualifiedResidentialTreatment";
	public static final String EXTENDEDFOSTERCAREINFO= "ExtendedFosterCareInfo";
	public static final String KINGAPINFORMATION= "KinGapInformation";
	public static final String ELIGIBILITYDOCUMENTS= "EligibilityDocuments";
	public static final String ELIGIBILITYHOMEOFREMOVAL= "EligibilityHomeOfRemoval";
	public static final String FOSTERCAREELIGIBILITYINFO= "FosterCareEligibilityInfo";
	public static final String COMMUNICATIONSANDTRANSACTIONS= "CommunicationsAndTransactions";
	public static final String TASK = "Task";
	public static final String ELIGIBILITYTASK = "EligibilityTask";
	public static final String ELIGIBILITYASSIGNMENTS = "EligibilityAssignments";
	public static final String CHILDINCOMEANDPROPERTY = "ChildIncomeAndProperty";
	public static final String ELIGIBILITYGENERATEDOCUMENT = "EligibilityGenerateDocument";
	public static final String SUBMITTOCALSAWS = "SubmitToCalSAWS";
	/*******************************Courts************************************/
	public static final String PETITIONALLEGATION = "PetitionAllegation";
	public static final String GENERATEDOCUMENT = "GenerateDocument";
	public static final String GENERATEPETITION = "GeneratePetition";
	public static final String AUDITHISTORY = "AuditHistory";
	public static final String COURTSAPPROVALAUDITHISTORY = "CourtsApprovalAuditHistory";
	public static final String COURTOFFICERNOTES = "CourtOfficerNotes";
	public static final String COURTREPORTS = "CourtReports";
	public static final String COURTMINUTEORDER = "CourtMinuteOrders";
	public static final String DOCUMENTDISTRIBUTIONS = "DocumentDistributions";
	public static final String RELATEDREFERRAL = "RelatedReferrals";
	public static final String COURTWORKITEMS = "CourtWorkItems";
	public static final String AMENDPETITION = "AmendPetition";
	public static final String COURTSDOCUMENTS = "CourtsDocuments";
	public static final String KNOWLEDGEARTICLE = "KnowledgeArticle";
	public static final String COURTCASE = "CourtCase";
	public static final String COURTWARRENTS = "CourtWarrents";
	public static final String COURTHEARINGS = "CourtHearings";
	public static final String PETITION = "Petition";
	public static final String ADHOCACTIVITY = "AdHocActivity";
	public static final String PARTICIPANTS = "Participants";
	public static final String RELATED = "Related";
	/*******************************Person************************************/
	public static final String PERSONSEARCH = "PersonSearch";
	public static final String PERSONCONTACTLOGMEMBERS = "PersonContactLogMembers";
	public static final String PERSONAKA = "PersonAKA";
	public static final String PERSONDETAILS = "PersonDetails";
	public static final String PERSONPHONE="PersonPhone";
	public static final String PERSONHISTORY = "PersonHistory";
	public static final String ACTIVEPERSONADDRESS="ActivePersonAddress";
	public static final String INACTIVEPERSONADDRESS="InactivePersonAddress";
	public static final String PERSONTRIBALINFORMATION = "PersonTribalInformation";
	public static final String PERSONHOUSEHOLDMEMBERSHIPS ="PersonHouseholdMemberships";
	public static final String PERSONRELATIONSHIPS ="PersonRelationships";
	public static final String PERSONADDRESSES = "PersonAddresses";
	public static final String PERSONBIBACKGROUNDCHECKS = "PersonBIBackgroundChecks";
	public static final String PERSONBIROI = "PersonBIROI";
	public static final String PERSONBIJSI = "PersonBIJSI";
	public static final String PERSONEIEDUCATION = "PersonEIEducation";
	public static final String PERSONEIPOSTEDUCATIONSUPPORT = "PostSecondaryEducationSupport";
	public static final String PERSONBHDIAGNOSIS = "PersonBHDiagnosis";
	public static final String PERSONBEHAVIORALEMOTIONALHEALTHNEEDS  = "PersonBehavioralEmotionalNeeds";
	public static final String PERSONALSTRENGTHSCOPINGSKILLS  = "PersonalStrengthsCopingSkills";
	public static final String SUBSTANCEDEPENDENCYTREATMENT  = "SubstanceDependencyTreatment";
	public static final String ALCOHOLDEPENDENCYTREATMENT  = "AlcoholDependencyTreatment";
	public static final String PERSONLEGALISSUES  = "PersonLegalIssues";
	public static final String PERSONHEALTHINFORMATION = "PersonHealthInformation";
	public static final String PERSONMEDICALEQUIPMENTREQUIREDINFORMATION ="MedicalEquipmentRequiredInformation";
	public static final String PERSONMEDICALEXAMSINFORMATION ="PersonMedicalExamsInformation";
	public static final String PERSONMEDICATIONSINFORMATION ="PersonMedicationsInformation";

	public static final String PERSONHEALTHALLERGIES ="PersonHealthAllergies";
	public static final String PERSONDENTALEXAM ="PersonDentalExam";
	public static final String PERSONHEARINGIMPAIRMENT ="PersonHearingImpairment";
	public static final String PERSONHOSPITALIZATIONS ="PersonHospitalizations"; 
	public static final String PERSONIMMUNIZATIONS ="PersonImmunizations";

	public static final String PERSONPHYSICALHEALTHVISUALIMPAIREMENT  = "PersonPHVisualImpairement";
	public static final String PERSONHEALTHINSURANCEMEDICAL  = "PersonHIMediCal";
	public static final String PERSONHEALTHINSURANCEMEDICAID  = "PersonHIMedicaid";
	public static final String OTHERHEALTHINSURANCECOVERAGE  = "OtherHealthInsuranceCoverage";
	public static final String PERSONPRESCRIPTIONDRUGS  = "PersonPrescriptionDrugs";
	
	public static final String PERSONREGIONALCENTERINFORMATION = "PersonRegionalCenterInformation";
	public static final String PERSONPREGNANACY = "PersonPregnancy";
	public static final String PERSONSPECIALDIETREQUIRED = "PersonSpecialDietRequired";
	public static final String PERSONMENTALHEALTH ="PersonMentalHealth";
	public static final String PERSONSOCIALHISTORY = "PersonSocialHistory";
	
    public static final String PERSONALLERGIES = "PersonAllergies";
	public static final String PERSONALCOHOLORSUBSTANCE = "AlcoholOrSubstanceUse";
	public static final String PERSONHEARINGIMPAIRMENTANDDEAFNESS = "HearingImpairmentAndDeafness";
	public static final String PRIORADOPTIONANDGUARDIANSHIP = "PriorAdoptionAndGuardianship";
	public static final String PRIORADOPTION = "PriorAdoption";
	public static final String PRIORGUARDIANSHIP = "PriorGuardianship";
	public static final String SCHOOLDISCIPLINARYISSUES = "SchoolDisciplinaryIssues";

    public static final String PERSONRELATED = "PersonRelated";
	/*********************** Organization ***********************************/
	public static final String ORGPROVIDERSEARCH = "OrganizationProviderSearch";



	
}	






