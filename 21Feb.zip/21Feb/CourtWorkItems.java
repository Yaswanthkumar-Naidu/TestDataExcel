package cares.cwds.salesforce.pom.courts;

import java.util.ArrayList;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;


import cares.cwds.salesforce.constants.ModuleConstants;
import cares.cwds.salesforce.constants.ScreenConstants;
import cares.cwds.salesforce.utilities.common.TestRunSettings;
import cares.cwds.salesforce.utilities.common.Util;
import cares.cwds.salesforce.utilities.reports.common.ReportCommon;
import cares.cwds.salesforce.utilities.reports.extentmodel.PageDetails;
import cares.cwds.salesforce.utilities.reports.model.TestCaseParam;
import cares.cwds.salesforce.utilities.testng.TestNGCommon;
import cares.cwds.salesforce.utilities.web.GenericLocators;
import cares.cwds.salesforce.utilities.web.Webkeywords;

public class CourtWorkItems {
	
	private WebDriver driver;
	ReportCommon exceptionDetails = new ReportCommon();
	Util util = new Util();
	GenericLocators genericLocators = null;
	TestNGCommon testngCommon = new TestNGCommon();
	TestCaseParam testCaseParam = (TestCaseParam) testngCommon.getTestAttribute("testCaseParam");
	String moduleName = ModuleConstants.COURTS;
	String screenName = ScreenConstants.COURTWORKITEMS;
	
public CourtWorkItems(){ }
	
	public CourtWorkItems(WebDriver wDriver)
	{
		initializePage(wDriver);
	}

	public void initializePage(WebDriver wDriver) 
    {
    	 driver = wDriver;
         PageFactory.initElements(driver, this);
         ReportCommon testStepLogDetails = new ReportCommon(); 
         testStepLogDetails.logModuleAndScreenDetails( moduleName, screenName);
         genericLocators = new GenericLocators(wDriver);
    }
	
	
	public void navigateToCourtWorkItems(String scriptIteration, String pomIteration){

		PageDetails action = new PageDetails();
		action.setPageActionName("Navigate to Court Work Items");
		action.setPageActionDescription("Navigate to Court Work Items");

		Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(), TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);

		Webkeywords.instance().click(driver, genericLocators.button(driver, "Court Record", testCaseDataSd.get("COURT_RECORD_EXPAND").get(0)), testCaseDataSd.get("COURT_RECORD_EXPAND").get(0),action);
		Webkeywords.instance().pauseDelay();
		Webkeywords.instance().click(driver, genericLocators.button(driver, "Court Work Items", testCaseDataSd.get("COURT_WORK_ITEMS").get(0)), testCaseDataSd.get("COURT_WORK_ITEMS").get(0),action);
     }
	
	
public void verifyCourtWorkItemsRelatedList(String scriptIteration, String pomIteration){
		
		PageDetails action = new PageDetails();
		action.setPageActionName("Validate Court Work Items Related List");
		action.setPageActionDescription("Validate Court Work Items Related List");

		Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(), TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);

		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Warrants",testCaseDataSd.get("WARRENTS").get(0)), testCaseDataSd.get("WARRENTS").get(0), action);
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Petitions",testCaseDataSd.get("PETITIONS").get(0)), testCaseDataSd.get("PETITIONS").get(0), action);
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Hearings",testCaseDataSd.get("HEARINGS").get(0)), testCaseDataSd.get("HEARINGS").get(0), action);
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Ad Hoc Activities",testCaseDataSd.get("AD_HOC_ACTIVITIES").get(0)), testCaseDataSd.get("AD_HOC_ACTIVITIES").get(0), action);		

	}

	
	

}
