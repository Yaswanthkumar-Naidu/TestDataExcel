package cares.cwds.salesforce.utilities.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.Properties;

public class InitializeTestSettings
{
	
    private static final Logger logger =LoggerFactory.getLogger(InitializeTestSettings.class.getName());

    public static final String CONFIGURATIONFOLDER = "configuration/";
    Properties prop=new Properties();

	Util util = new Util();

	// Get the current working directory
	static String projectRoot = System.getProperty("user.dir");

	// Function to get the absolute path based on the project root and the relative path
	public static String getAbsolutePath(String relativePath) {
		return Paths.get(projectRoot, relativePath).toAbsolutePath().toString();
	}

	public void loadConfigData(String prjPath) {
		try {
			// Construct the file path in a cross-platform manner
			String configFilePath = Paths.get(prjPath, CONFIGURATIONFOLDER +"config.properties").toString();
			File configFile = new File(configFilePath);

			if (!configFile.exists()) {
				throw new IOException("Config file not found: " + configFile.getAbsolutePath());
			}

			prop = new Properties();
			try (FileInputStream fis = new FileInputStream(configFile)) {
				prop.load(fis);
			}

			TestRunSettings.setHomePath(prjPath);
			TestRunSettings.setEnvironment(prop.getProperty("Environment").toUpperCase().trim());
			TestRunSettings.setUrl(prop.getProperty(TestRunSettings.getEnvironment()+".URL"));
			TestRunSettings.setSalesforceUrl(prop.getProperty(TestRunSettings.getEnvironment()+".SALESFORCEURL"));
			TestRunSettings.setProjectName(prop.getProperty("ProjectName"));
			TestRunSettings.setRelease(prop.getProperty("Release"));
			TestRunSettings.setADAValidation(prop.getProperty("ADAValidation"));


			TestRunSettings.setTestRunName(prop.getProperty("TestRunName"));
			TestRunSettings.setExecutedBy(prop.getProperty("ExecutedBy"));
			TestRunSettings.setBrowser(prop.getProperty("Browser"));

			if (prop.getProperty("CustomBrowserLocation").equalsIgnoreCase("Yes")) {
				TestRunSettings.setBrowserLocation(prop.getProperty("BrowserLocation"));
			} else {
				TestRunSettings.setBrowserLocation(TestRunSettings.getHomePath() + "/Drivers");
			}

			TestRunSettings.setMaximizedMode(prop.getProperty("MaximizedMode").equalsIgnoreCase("Yes"));
			TestRunSettings.setSnapshotForAllPass(prop.getProperty("SnapshotForAllPass").equalsIgnoreCase("Yes"));
			TestRunSettings.setFullPageScreenshot(prop.getProperty("FullPageScreenshot").equalsIgnoreCase("Yes"));

			TestRunSettings.setPageLoadTimeout(Integer.parseInt(prop.getProperty("PageLoadTimeout")));
			TestRunSettings.setElementTimeout(Integer.parseInt(prop.getProperty("ElementTimeout")));
			TestRunSettings.setElementTimeoutLongWait(Integer.parseInt(prop.getProperty("ElementTimeoutLongWait")));

			//run in headless mode
			TestRunSettings.setRunInHeadlessMode(prop.getProperty("runInHeadlessMode"));
			TestRunSettings.setCaptureUIPerformance(prop.getProperty("CaptureUIPerformance"));
			TestRunSettings.setUiPerfFileName(prop.getProperty("UIPerfFileName"));
			// Set the Artifacts Path and other paths dynamically
			TestRunSettings.setArtifactsPath(getAbsolutePath(prop.getProperty("ArtifactsPath")));
			TestRunSettings.setTestDataPath(getAbsolutePath(prop.getProperty("TestDataPath")));
			TestRunSettings.setTestDataMappingFileName(getAbsolutePath(prop.getProperty("TestDataMappingFileName")));
			TestRunSettings.setTestDataMappingSheetNameSd(prop.getProperty("TestDataMappingSheetName_SD"));
			TestRunSettings.setTestDataLocationCs(getAbsolutePath(prop.getProperty("TestDataLocation_CS")));
			TestRunSettings.setUploadDocumentPath(getAbsolutePath(prop.getProperty("UploadDocumentPath")));

            TestRunSettings.setUploadFilePath(getAbsolutePath(prop.getProperty("UploadFilePath")));
            TestRunSettings.setOutputFilePath(getAbsolutePath(prop.getProperty("ScreeningIDsFilePath")));
            TestRunSettings.setOutputFileName(prop.getProperty("ScreeningIDsFileName"));
            TestRunSettings.setTimeOutWait(Integer.parseInt(prop.getProperty("timeOutWait")));
            TestRunSettings.setRetryAttempts(Integer.parseInt(prop.getProperty("retryAttempts")));
            TestRunSettings.setFluentWait(Integer.parseInt(prop.getProperty("fluentWaitInMin")));
            TestRunSettings.setPollingEvery(Integer.parseInt(prop.getProperty("pollingAfterEverySec")));
            TestRunSettings.setGridExecution(prop.getProperty("gridExecution"));
            TestRunSettings.setPauseFlag(prop.getProperty("pauseFlag"));
            TestRunSettings.setFullPageSS(prop.getProperty("fullPageSS"));


			TestRunSettings.setConfigLocation(getAbsolutePath(prop.getProperty("ConfigLocation")));
			TestRunSettings.setApplicationCredentialsFileName(getAbsolutePath(prop.getProperty("ApplicationCredentialsFileName")));
			TestRunSettings.setApplicationCredentialsSheetName(prop.getProperty("ApplicationCredentialsSheetName"));

			TestRunSettings.setResultsPath(getResultsPath());

			TestRunSettings.setParallelExecution(prop.getProperty("ParallelExecution").equalsIgnoreCase("Yes"));
			if (TestRunSettings.isParallelExecution()) {
				TestRunSettings.setParallelNodesCount(Integer.parseInt(prop.getProperty("ParallelNodes")));
				TestRunSettings.setParallelExecutionConfig(prop.getProperty("ParallelExecutionConfig"));
				TestRunSettings.setParallelNodeSheetAssociation(prop.getProperty("ParallelNodeSheetAssociation"));
			}

			TestRunSettings.setLoadDriverOptions(loadDriverDetails());
			TestRunSettings.setChromeConfig(prop.getProperty("ChromeConfig"));
			TestRunSettings.setFireFoxConfig(prop.getProperty("FireFoxConfig"));
			TestRunSettings.setIeConfig(prop.getProperty("IEConfig"));
			TestRunSettings.setEdgeConfig(prop.getProperty("EdgeConfig"));
			TestRunSettings.setOperaConfig(prop.getProperty("OperaConfig"));
			TestRunSettings.setCloudConfig(prop.getProperty("CloudConfig"));
			
			TestRunSettings.setFireFoxLocation(prop.getProperty("FireFoxLocation"));
			TestRunSettings.setIeDriverLocation(TestRunSettings.getHomePath() + prop.getProperty("IEDriverLocation"));
			TestRunSettings.setOperaLocation(TestRunSettings.getHomePath() + prop.getProperty("IEDriverLocation"));

			TestRunSettings.setUploadDocumentPath(TestRunSettings.getArtifactsPath() + prop.getProperty("UploadDocumentLocation"));

			TestRunSettings.setInterfaceSheetDetails(prop.getProperty("InterfaceSheetDetails"));
			TestRunSettings.setExcelSheetExtension(prop.getProperty("ExcelSheetExtension"));
			TestRunSettings.setXmlExtension(prop.getProperty("XMLExtension"));
			TestRunSettings.setJsonExtension(prop.getProperty("JSONExtension"));
			TestRunSettings.setCommonMockSheetName(prop.getProperty("CommonMockSheetName"));
			TestRunSettings.setUseCommonMockSheet(prop.getProperty("UseCommonMockSheet"));
			TestRunSettings.setMockTemplateLocation(TestRunSettings.getArtifactsPath() + prop.getProperty("MockTemplateLocation"));

			TestRunSettings.setHeaderRepositorySheetName(prop.getProperty("HeaderRepositorySheetName"));
			TestRunSettings.setDefaultServiceTimeout(Integer.parseInt(prop.getProperty("DefaultServiceTimeout")));

			
		
			TestRunSettings.setAdaToolPath(TestRunSettings.getArtifactsPath() + prop.getProperty("AdatoolPath"));

			TestRunSettings.setMasterSheetName(prop.getProperty("masterSheetName"));
			TestRunSettings.setMasterScriptExecutionFlag(prop.getProperty("masterScriptExecutionFlag"));
			
			String constantDateFilepath = Paths.get(prjPath, CONFIGURATIONFOLDER +"constant.properties").toString();
			TestRunSettings.setConstantDataPath(constantDateFilepath);
			
		} catch (Exception e) {
			logger.info("Failed to Initialize the Test Run Settings");
		}
	}

	String getMockSheetName(String useCommonMockSheet, String commonMockSheetName, String environment)
	{

		if ("YES".equals(useCommonMockSheet.toUpperCase().trim()))
		{
			return commonMockSheetName;
		}
		else
		{
			return environment;
		}
	}

	
	public boolean loadDriverDetails()
	{
		try
		{
			return "YES".equalsIgnoreCase(prop.getProperty("LoadDriverOptions").trim());

		}
		catch (Exception e)
		{
			logger.info("Failed to Initialize the Driver Load Details");
		}
		return false;
	}

	public String getResultsPath(){
	  
	        if (prop.getProperty("SetCustomResultLocation").toUpperCase().trim().equals("YES")) {
	            File dir = new File(prop.getProperty("CustomResultLocation") + File.separator + Util.getCurrentDate() + File.separator + "Run_" + Util.getCurrentTime());

	            if (!dir.exists()) dir.mkdirs();
	            return prop.getProperty("CustomResultLocation") + "/" + Util.getCurrentDate() + "/Run_" + Util.getCurrentTime();
	        } else {
	            String resultFolder = TestRunSettings.getHomePath() + "/" + prop.getProperty("DefaultResultLocation") + "/" + Util.getCurrentDate() + "/Run_" + Util.getCurrentTime();
	            File dir = new File(resultFolder);
	            if (!dir.exists()) dir.mkdirs();

	            return resultFolder;
	        }
	    }
	}