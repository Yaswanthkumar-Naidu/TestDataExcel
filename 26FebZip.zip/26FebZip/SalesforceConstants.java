package cares.cwds.salesforce.constants;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cares.cwds.salesforce.utilities.common.AWSSecretsManager;
import cares.cwds.salesforce.utilities.common.TestRunSettings;
import cares.cwds.salesforce.utilities.web.SalesforceCommon;

public class SalesforceConstants {
	
	private SalesforceConstants() {
		throw new IllegalStateException("Constants class");
	}

	private static Map<String,String[]> loginMap = new HashMap<>();
	private static Map<String, Object> salesforceMap = new HashMap<>();
	public static Map<String, String> salesforceMap1 = new HashMap<>();
	private static Map<String, Map<String, String[]>> salesforceMap2 = new HashMap<>();
	private static Map<String,String> usersMap = new HashMap<>();
	private static final Logger logger = LoggerFactory.getLogger(SalesforceConstants.class.getName());
	private static final String TITLEIVSTAFFCDSSPLACEMENT= "TitleIVStaffCDSSPlacement";
	private static final String HLWORKERCONTRACOSTA= "HLWorkerContraCosta";
	private static final String HLSUPERVISORCONTRACOSTA= "HLSupervisorContraCosta";
	private static final String HLSUPERVISORCONTRACOSTA2= "HLSupervisorContraCosta2";
	private static final String CMMANAGERCONTRACOSTA= "CMManagerContraCosta";
	private static final String CMSUPERVISORCONTRACOSTA= "CMSupervisorContraCosta";
	private static final String CMWORKERCONTRACOSTA= "CMWorkerContraCosta";
	private static final String CMWORKERCONTRACOSTA2= "CMWorkerContraCosta2";
	private static final String ERSUPERVISORCONTRACOSTA= "ERSupervisorContraCosta";
	private static final String ERWORKERCONTRACOSTA= "ERWorkerContraCosta";
	
	private static final String HLSUPERVISORFRESNO= "HLSupervisorFresno";
	private static final String HLWORKERFRESNO= "HLWorkerFresno";
	private static final String ERWORKERFRESNO= "ERWorkerFresno";
	private static final String ERSUPERVISORFRESNO= "ERSupervisorFresno";

	
	public static final String POMITERATION1 = "1";
	public static final String POMITERATION2 = "2";
	public static final String POMITERATION3 = "3";
	public static final String POMITERATION4 = "4";
	public static final String POMITERATION5 = "5";
	public static final String POMITERATION6 = "6";
	public static final String POMITERATION7 = "7";
	public static final String POMITERATION8 = "8";
	public static final String POMITERATION9 = "9";
	public static final String POMITERATION10 = "10";
	public static final String POMITERATION11 = "11";
	public static final String POMITERATION12 = "12";
	public static final String POMITERATION13 = "13";
	public static final String POMITERATION14 = "14";
	public static final String POMITERATION15 = "15";
	public static final String POMITERATION16 = "16";
	public static final String POMITERATION17 = "17";
	public static final String POMITERATION18 = "18";
	public static final String POMITERATION19 = "19";
	public static final String POMITERATION20 = "20";
	
	public static final String NEGATIVEPOMITERATION1 = "NG1";

	public static final String SCREENINGURL = "SCREENING";
	public static final String REFERRALURL = "REFERRAL";
	public static final String CASEURL = "CASE";
	public static final String ELIGIBILITYURL = "ELIGIBILITY";
	public static final String PERSONURL = "PERSON";

	public static final String SCR = "SCR";
	public static final String SCREENING = "Screenings";
	public static final String REFERRAL = "REFERRAL";
	public static final String PERSON = "PERSON";
	public static final String INV_CASE = "INV_CASE";
	public static final String NON_INV_CASE = "NON_INV_CASE";
	public static final String FAMILY_TRANSFER = "FAMILY_TRANSFER";
	public static final String CHILD_LOCATION = "CHILD_LOCATION";
	public static final String ELIGIBILITY = "ELIGIBILITY";
	public static final String HEARINGCOURTWORKITEMURL = "HEARINGCOURTWORKITEM";
	public static final String PETITION = "PETITION";
	public static final String AMENDEDPETITION = "AMENDEDPETITION";
	
	public static final String LOGINUSER = "LOGIN_USER";
	public static final String HLWORKER= "HL_WORKER";
	public static final String HLSUPERVISOR = "HL_SUPERVISOR";
	public static final String HLSUPERVISOR2 = "HL_SUPERVISOR2";
	public static final String ERWORKER = "ER_WORKER";
	public static final String CMWORKER = "CM_WORKER";
	public static final String CMSUPERVISOR = "CM_SUPERVISOR";
	public static final String CMMANAGER = "CM_MANAGER";
	public static final String TITLEIV = "TITLEIV";
	public static final String CDSS = "CDSS";
	public static final String ERSUPERVISOR = "ER_SUPERVISOR";
	public static final String CLERICALWORKER = "CLERICAL_WORKER";
	public static final String CMSUPERVISORFRESNO = "CM_SUPERVISORFRESNO";
	public static final String CMWORKERFRESNO = "CMWorkerFresno";
	
	
	private static int screenshotCounter = 1;

	/**
	 * This method sets salesforce variable to map
	 * @param constantName
	 * @param constantValue
	 * @return 
	 */
	public static void setConstantValue(String constantName, String constantValue) {
		salesforceMap1.put(constantName.replaceAll("\\s+", "").toLowerCase(), constantValue);
	}
	

	/**
	 * This method gets salesforce variable from the map
	 * @param constantName
	 * @return
	 */
	public static String getConstantValue(String constantName) {
		return salesforceMap1.get(constantName.replaceAll("\\s+", "").toLowerCase());
	}
	

	/**
	 * This method sets salesforce variable to map
	 * @param objectName
	 * @param objectValue
	 * @return 
	 */
	public static void setObjectValue(String objectName, Map<String, String[]> objectValue) {
		salesforceMap2.put(objectName.replaceAll("\\s+", "").toLowerCase(), objectValue);
	}
	
	/**
	 * This method gets salesforce variable from the map
	 * @param objectName
	 * @return
	 */
	public static Map<String, String[]> getObjectValue(String objectName) {
		return salesforceMap2.get(objectName.replaceAll("\\s+", "").toLowerCase());
	}

	
	/**
	 * This method gets salesforce variable from the map
	 * @param constantName
	 * @return
	 */
	public static String getConstantValueObject(String constantName) {
		return (String) salesforceMap.get(constantName.replaceAll("\\s+", "").toLowerCase());
	}
	
	
	
	/**
	 * Method to set loginMap
	 */
	public static void intializeAppUsers() {		
	try {
		AWSSecretsManager.loadAWSSecretPasswords();
	} catch (IOException e) {
		  logger.info(Arrays.toString(e.getStackTrace()));
		  throw new NullPointerException("Exception occurred while retreiving passwords on AWS secrets manager");
	}	
	
		
	String exeEnv = TestRunSettings.getEnvironment();
	if(exeEnv.equalsIgnoreCase("qa")) {
		loginMap.put(HLWORKERCONTRACOSTA,returnAWSPassword("AutoHLworker2_2024_contracosta_V1QA@nomail.osi.ca.gov",exeEnv));
		loginMap.put(HLSUPERVISORCONTRACOSTA,returnAWSPassword("AutoHLSupervisor2_2024_contracosta_V1QA",exeEnv));
		loginMap.put(ERWORKERCONTRACOSTA,returnAWSPassword("AutoERworker2_2024_contracosta_V1QA",exeEnv));
		loginMap.put(ERSUPERVISORCONTRACOSTA,returnAWSPassword("AutoERSupervisor2_2024_contracosta_V1QA",exeEnv));
		loginMap.put(CMWORKERCONTRACOSTA, returnAWSPassword("AutoCMworker2_2024_contracosta_V1QA",exeEnv));
		loginMap.put(CMSUPERVISORCONTRACOSTA,returnAWSPassword("AutoCMSupervisor2_2024_contracosta_V1QA",exeEnv));
		loginMap.put(CMMANAGERCONTRACOSTA,returnAWSPassword("AutoCMmanager2_2024_contracosta_V1QA",exeEnv));
		loginMap.put(TITLEIVSTAFFCDSSPLACEMENT, returnAWSPassword("AutoTitleIV_CDSSPlacement2024_State_V1QA",exeEnv));
		//Fresno county Users
		loginMap.put(HLWORKERFRESNO, returnAWSPassword("Auto_Hstaff2_Fresno_V1_QA",exeEnv));
		loginMap.put(HLSUPERVISORFRESNO, returnAWSPassword("Auto_HSupervisor2_Fresno_V1_QA",exeEnv));
		loginMap.put(ERWORKERFRESNO, returnAWSPassword("autoer_worker_fresno_V1_QAt@osi.ca.gov",exeEnv));
		loginMap.put(ERSUPERVISORFRESNO, returnAWSPassword("autoer_worker_fresno_V1_QAt@osi.ca.gov",exeEnv));
		
	} else if (exeEnv.equalsIgnoreCase("sit")) {
		
		loginMap.put("TitleIVStaffPlacer", returnAWSPassword("Auto_TitleIV_Staff_Placer@osi.ca.gov",exeEnv));
		loginMap.put(TITLEIVSTAFFCDSSPLACEMENT, returnAWSPassword("AutoTitleIV_Placement_State_V1SIT@osi.ca.gov",exeEnv));
		loginMap.put(CDSS, returnAWSPassword("Auto_CDSS_Staff_Placer@osi.ca.gov",exeEnv));
		loginMap.put(HLWORKERCONTRACOSTA, returnAWSPassword("Auto_Hstaff1_ContraCosta_V1_SIT@nomail.ca.gov",exeEnv));
		loginMap.put(HLSUPERVISORCONTRACOSTA, returnAWSPassword("Auto_Hsupervisor1_ContraCosta_V1_SIT@nomail.ca.gov",exeEnv));
		loginMap.put(ERWORKERCONTRACOSTA, returnAWSPassword("auto_erworker3_contracosta_v1sit@osi.ca.gov",exeEnv));
		loginMap.put(ERSUPERVISORCONTRACOSTA, returnAWSPassword("auto_supervisor3_contracosta_v1sit@osi.ca.gov",exeEnv));
		loginMap.put(CMWORKERCONTRACOSTA, returnAWSPassword("AutoCMworker4201_Contracosta_V1SIT@osi.ca.gov",exeEnv));
		loginMap.put(CMSUPERVISORCONTRACOSTA, returnAWSPassword("AutoCMSupervisor4201_Contracosta_V1SIT@osi.ca.gov",exeEnv));
		loginMap.put(CMMANAGERCONTRACOSTA, returnAWSPassword("AutoCMManager4201_Contracosta_V1SIT@osi.ca.gov",exeEnv));
		loginMap.put("HLWorkerContraCosta2", returnAWSPassword("",exeEnv));
		loginMap.put(HLSUPERVISORCONTRACOSTA2, returnAWSPassword("Autohotline155_supervisor_contracosta_V1SIT@osi.ca.gov",exeEnv));
		
		//Fresno county Users
		loginMap.put(HLWORKERFRESNO, returnAWSPassword("Auto_Hstaff2_Fresno_V1_SIT@nomail.ca.gov",exeEnv));
		loginMap.put(HLSUPERVISORFRESNO, returnAWSPassword("Auto_HSupervisor2_Fresno_V1_SIT@nomail.ca.gov",exeEnv));
		loginMap.put(ERWORKERFRESNO, returnAWSPassword("autoer_worker_fresno_V1sit@osi.ca.gov",exeEnv));
		loginMap.put(CMWORKERFRESNO, returnAWSPassword("Autocmworker4200_Fresno_V1SIT@osi.ca.gov",exeEnv));
		loginMap.put(ERSUPERVISORFRESNO, returnAWSPassword("autoer_worker_fresno_V1_QAt@osi.ca.gov",exeEnv));
		loginMap.put(CMSUPERVISORFRESNO, returnAWSPassword("AutoCMSupervisor358_Fresno_V1QA@OSI.ca.gov",exeEnv));
	} else if (exeEnv.equalsIgnoreCase("eust")) {
		loginMap.put(HLWORKERCONTRACOSTA,returnAWSPassword("testautomation@otsi.ca.gov.v1eust", exeEnv));
		loginMap.put(HLSUPERVISORCONTRACOSTA,returnAWSPassword("testautomation@otsi.ca.gov.v1eust", exeEnv));


}
}
	
	
	
	/**
	 * Method to get login credentials for given userId
	 * @param UserId
	 * @return
	 * 
	 * loginMap.get("HLWorkerContraCosta);
	 */
	public static String[] getUserCredentials(String userId) {
		return loginMap.get(userId);
	}

	private static String[] returnAWSPassword(String userId, String env) {
		AWSSecretsManager passwordManager = new AWSSecretsManager();
		return new String[] { userId, passwordManager.returnPassword(env+"."+userId.trim())};
	}
	
	/**
	 * Method to set users to be used in updating the user name entering drop-downs.
	 */
	public static void getAppUsers() {	

	String exeEnv = TestRunSettings.getEnvironment();
	if(exeEnv.equalsIgnoreCase("qa")) {
		usersMap.put(HLWORKERCONTRACOSTA,"Hotline Staff1 Contra Costa" );
		usersMap.put(HLSUPERVISORCONTRACOSTA,"Auto_Hotline Supervisor1 Contra Costa" );
		usersMap.put(ERWORKERCONTRACOSTA,"erworker3 auto" );
		usersMap.put(ERSUPERVISORCONTRACOSTA," " );
		usersMap.put(CMWORKERCONTRACOSTA, " " );
		usersMap.put(CMSUPERVISORCONTRACOSTA," " );
		usersMap.put(CMMANAGERCONTRACOSTA," " );
		usersMap.put(TITLEIVSTAFFCDSSPLACEMENT," " );
		usersMap.put("ClericalWorker1ContraCosta","Clerical Worker1 Contra Costa" );
		//Fresno
		usersMap.put(HLWORKERFRESNO,"Hotline Staff2 Fresno");
		usersMap.put(HLSUPERVISORFRESNO,"Hotline Supervisor2 Fresno");
		usersMap.put(ERWORKERFRESNO, "AutoER worker" );
		
	} else if (TestRunSettings.getEnvironment().equalsIgnoreCase("sit")) { 
		usersMap.put("TitleIVStaffPlacer", " " );
		usersMap.put(TITLEIVSTAFFCDSSPLACEMENT," " );
		usersMap.put(HLWORKERCONTRACOSTA, "Hotline Staff1 Contra Costa" );
		usersMap.put(HLSUPERVISORCONTRACOSTA, "Auto_Hotline Supervisor1 Contra Costa" );
		usersMap.put(ERWORKERCONTRACOSTA, "erworker3 auto" );
		usersMap.put(ERSUPERVISORCONTRACOSTA,"Erwupervisor3 Auto" );
		usersMap.put(CMWORKERCONTRACOSTA, "Autocase4201 worker 4201" );
		usersMap.put(CMSUPERVISORCONTRACOSTA,"Autocase 4201 Supervisor4201" );
		usersMap.put(CMMANAGERCONTRACOSTA,"Autocase4201 manager4201" );
		usersMap.put("ClericalWorker1ContraCosta","Clerical Worker1 Contra Costa" );
		usersMap.put(HLSUPERVISORCONTRACOSTA2, "Autosupervisor155" );
		usersMap.put(CMWORKERCONTRACOSTA2, "autoCMworker451 Ccost" );

		//Fresno
		usersMap.put(HLWORKERFRESNO,"Hotline Staff2 Fresno");
		usersMap.put(HLSUPERVISORFRESNO,"Hotline Supervisor2 Fresno");
		usersMap.put(ERWORKERFRESNO, "AutoER worker" );
		usersMap.put(ERSUPERVISORFRESNO,"Erwupervisor3 Auto" );
		usersMap.put(CMWORKERFRESNO, "Auto case4200 worker4200" );
	}
}
	
	/**
	 * Method to get userId
	 * @param UserId
	 * @return
	 * 
	 * loginMap.get("HLWorkerContraCosta);
	 */
	public static String getUserName(String userId) {
		return usersMap.get(userId);
	}


	public static int getSCREENSHOTCOUNTER() {
		return screenshotCounter;
	}


	public static void setSCREENSHOTCOUNTER(int sCREENSHOTCOUNTER) {
		screenshotCounter = sCREENSHOTCOUNTER;
	}
	
	public static void getCurrentPageUrl(WebDriver driver, String value) {
		SalesforceCommon.captureRecordURL(driver,value);
	}
	
}
