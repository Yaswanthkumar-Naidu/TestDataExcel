package cares.cwds.salesforce.pom.referralcase;

import static java.lang.String.format;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import cares.cwds.salesforce.constants.ModuleConstants;
import cares.cwds.salesforce.constants.SalesforceConstants;
import cares.cwds.salesforce.constants.ScreenConstants;
import cares.cwds.salesforce.pom.referral.Person;
import cares.cwds.salesforce.utilities.common.TestRunSettings;
import cares.cwds.salesforce.utilities.common.Util;
import cares.cwds.salesforce.utilities.reports.common.ReportCommon;
import cares.cwds.salesforce.utilities.reports.common.ScreenshotCommon;
import cares.cwds.salesforce.utilities.reports.extentmodel.PageDetails;
import cares.cwds.salesforce.utilities.reports.model.TestCaseParam;
import cares.cwds.salesforce.utilities.testng.TestNGCommon;
import cares.cwds.salesforce.utilities.web.GenericLocators;
import cares.cwds.salesforce.utilities.web.SalesforceCommon;
import cares.cwds.salesforce.utilities.web.Webkeywords;

public class CaseReferralPersons {

	private static final Logger logger = LoggerFactory.getLogger(CaseReferralPersons.class.getName());
	private WebDriver driver;
	ReportCommon exceptionDetails = new ReportCommon();
	Util util = new Util();
	GenericLocators genericLocators = null;
	TestNGCommon testngCommon = new TestNGCommon();
	TestCaseParam testCaseParam = (TestCaseParam) testngCommon.getTestAttribute("testCaseParam");

	String moduleName = ModuleConstants.CASE;
	String screenName = ScreenConstants.CASEREFERRALPERSONS;
	
	public CaseReferralPersons() {
	}

	public CaseReferralPersons(WebDriver wDriver) {
		initializePage(wDriver);
	}

	public void initializePage(WebDriver wDriver) {
		logger.info(this.getClass().getName());
		driver = wDriver;
		PageFactory.initElements(driver, this);
		ReportCommon testStepLogDetails = new ReportCommon();
		testStepLogDetails.logModuleAndScreenDetails( moduleName, screenName);
		genericLocators = new GenericLocators(wDriver);
	}

	@FindBy(how = How.XPATH, using = "//*[@title='Folio Person ID']/..//lightning-formatted-text")
	public WebElement newFoliopersonId;
	
	@FindBy(how = How.XPATH, using = "//records-entity-label[text()='Person Relationship']//ancestor::h1//following::slot//lightning-formatted-text[contains(text(),'REL')]")
	public WebElement personRelationshipId;
	
	@FindBy(how = How.XPATH, using = "(//label[text()='Status'])[1]")
	public WebElement status;
	
	@FindBy(how = How.XPATH, using = "//span[text()='Validate Person']")
	public WebElement validateSection;
		
	String columnHeader = "//table[@aria-label='%s']/thead/tr/th[@*='%s']//span//span[2]";
	
	String folioPersonValidatedName = "//table[@aria-label='Case Persons' or @aria-label='Persons']//*[@data-label='Validated Person Name']//a[text()='%s']";
	
    String folioPersonIdLink = "//table[@aria-label='Case Persons' or @aria-label='Persons' ]//*[@data-label='Person ID']//a[text()='%s']";
    
    String folioPersonRole = "//table[@aria-label='Case Persons' or @aria-label='Persons']//*[@data-label='Role']//lightning-base-formatted-text[text()='%s']";
    
	@FindBy(how = How.XPATH, using = "//table[@aria-label='Folio Persons']//*[@data-label='Role']//*[text()='Perpetrator']//ancestor::tr//*[@data-label='Folio Person ID']//a")
	public WebElement perpetratorIdLink;
	
	@FindBy(how = How.XPATH, using = "//table[@aria-label='Case Persons' or @aria-label='Persons']//tr//*[@data-label='Person ID']//span//a")
	public List<WebElement> casePersonIds;
	
	@FindBy(how = How.XPATH, using = "//table[@aria-label='Case Persons' or @aria-label='Persons']//tr//*[@data-label='Validated Person Name']//span//a")
	public List<WebElement> casePersonNames;
	
	@FindBy(how = How.XPATH, using = "//table[@aria-label='Case Persons' or @aria-label='Persons']//tr//*[@data-label='Role']//span")
	public List<WebElement> casePersonRoles;
	

	public void navigateToCaseFolioPersons( String scriptIteration, String pomIteration){
		PageDetails action = new PageDetails();
		
		action.setPageActionName("Navigate to Case Folio Persons");
		action.setPageActionDescription("Navigate to Case Folio Persons");
		
		Map<String, ArrayList<String>> testCaseDataSd = util.getScreenTCData(screenName,
				testCaseParam.getTestNGTestMethodName(), TestRunSettings.getTestDataPath(),
				TestRunSettings.getTestDataMappingFileName(), TestRunSettings.getTestDataMappingSheetNameSd(),
				scriptIteration, pomIteration);

		String personsTabFolio = testCaseDataSd.get("FOLIO_PERSONS_TAB").get(0);
		Webkeywords.instance().click(driver, genericLocators.link(driver, "Persons", personsTabFolio),
				personsTabFolio, action);
	}
	
	public void addCaseFolioPerson( String scriptIteration, String pomIteration) {
		PageDetails action = new PageDetails();
		action.setPageActionName("Add Case Folio Person");
		action.setPageActionDescription("Add Case Folio Person");
	
		Map<String, ArrayList<String>> testCaseDataSd = util.getScreenTCData(screenName,
				testCaseParam.getTestNGTestMethodName(), TestRunSettings.getTestDataPath(),
				TestRunSettings.getTestDataMappingFileName(), TestRunSettings.getTestDataMappingSheetNameSd(),
				scriptIteration, pomIteration);
		
		String newButton = testCaseDataSd.get("NEW_BTN").get(0);
		String lname = util.getRandom(testCaseDataSd.get("FOLIO_PERSON_LASTNAME").get(0));
		String fname = util.getRandom(testCaseDataSd.get("FOLIO_PERSON_FIRSTNAME").get(0));
		String folioRole = testCaseDataSd.get("FOLIO_PERSON_ROLE").get(0);
		String newpersonBtnTD =testCaseDataSd.get("NEWPERSON_BTN").get(0);
		String saveBtnTD =testCaseDataSd.get("SAVE_BTN").get(0);

		Webkeywords.instance().scrollUpPageToTheTop(driver);
		Webkeywords.instance().click(driver, genericLocators.button(driver, "New", newButton), newButton,action);
		Webkeywords.instance().setText(driver,genericLocators.textbox(driver, "First Name", testCaseDataSd.get("FOLIO_PERSON_FIRSTNAME").get(0)), fname,action);
		Webkeywords.instance().setText(driver,genericLocators.textbox(driver, "Last Name", testCaseDataSd.get("FOLIO_PERSON_LASTNAME").get(0)), lname,action);
		Webkeywords.instance().selectInputDropdownValue(driver, testCaseDataSd.get("SEXATBIRTH").get(0),"Sex at Birth", action);
		Webkeywords.instance().click(driver,genericLocators.button(driver, "Search", testCaseDataSd.get("SEARCH_BTN").get(0)),testCaseDataSd.get("SEARCH_BTN").get(0), action);
		Webkeywords.instance().click(driver, genericLocators.button(driver, "New Person", newpersonBtnTD),newpersonBtnTD, action);
		SalesforceCommon.verifyToastMessage(driver,"Person associated successfully.",action);
		//Webkeywords.instance().refresh(driver, action);
		
		Webkeywords.instance().selectInputDropdownValue(driver,folioRole,"Role",action);
		ScreenshotCommon.captureFullPageScreenShot(driver, moduleName+"-"+screenName);	
		Webkeywords.instance().click(driver, genericLocators.button(driver, "Save",saveBtnTD), saveBtnTD, action);
		if(folioRole.equalsIgnoreCase("Focus Child"))
			SalesforceCommon.verifyToastMessage(driver,"Please clear validation errors before saving.1. A Focus Child has already been added to this Case.", action);
		else {
			SalesforceCommon.verifyToastMessage(driver,"Data saved successfully.",action);
			SalesforceConstants.setConstantValue("FP_ID"+pomIteration, genericLocators.recordID(driver, "Person ID", "").getText());
			SalesforceConstants.setConstantValue("folioPersonName"+pomIteration, fname+" "+lname);
		}
	}
	
	public void editCaseFolioPerson( String scriptIteration, String pomIteration) {
		PageDetails action = new PageDetails();
		action.setPageActionName("Edit Case Folio Person");
		action.setPageActionDescription("Edit Case Folio Person");
	
		Map<String, ArrayList<String>> testCaseDataSd = util.getScreenTCData(screenName,
				testCaseParam.getTestNGTestMethodName(), TestRunSettings.getTestDataPath(),
				TestRunSettings.getTestDataMappingFileName(), TestRunSettings.getTestDataMappingSheetNameSd(),
				scriptIteration, pomIteration);
		
		String folioRole = testCaseDataSd.get("FOLIO_PERSON_ROLE").get(0);
		String saveBtnTD =testCaseDataSd.get("SAVE_BTN").get(0);

		Webkeywords.instance().waitElementToBeVisible(driver, genericLocators.dropdown(driver, "Role", folioRole));
		Webkeywords.instance().selectInputDropdownValue(driver,folioRole,"Role",action);
		Webkeywords.instance().click(driver, genericLocators.button(driver, "Save",saveBtnTD), saveBtnTD, action);
		
		if(folioRole.equalsIgnoreCase("Focus Child"))
			SalesforceCommon.verifyToastMessage(driver,"Please clear validation errors before saving.1. A Focus Child has already been added to this Case.", action);
		else
			SalesforceCommon.verifyToastMessage(driver,"Data saved successfully.",action);
	}
	
	public void verifyCaseFolioPersonHeaderColumnsInTable(String tableName, String scriptIteration, String pomIteration) {
		PageDetails action = new PageDetails();
		
		action.setPageActionName("Verify Case Folio Person header columns in Table");
		action.setPageActionDescription("Verify Case Folio Person header columns in Table");
			
		Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(), TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);

		Webkeywords.instance().verifyElementDisplayed(driver, getElementBasedOnFlag(testCaseDataSd.get("FOLIO_PERSON_ID_VERIFY").get(0),columnHeader,tableName,"Folio Person ID"), testCaseDataSd.get("FOLIO_PERSON_ID_VERIFY").get(0), action);
		Webkeywords.instance().verifyElementDisplayed(driver, getElementBasedOnFlag(testCaseDataSd.get("VALIDATED_PERSON_NAME_VERIFY").get(0),columnHeader,tableName,"Validated Person Name"), testCaseDataSd.get("VALIDATED_PERSON_NAME_VERIFY").get(0), action);
		Webkeywords.instance().verifyElementDisplayed(driver, getElementBasedOnFlag(testCaseDataSd.get("FIRST_NAME_VERIFY").get(0),columnHeader,tableName,"First Name"), testCaseDataSd.get("FIRST_NAME_VERIFY").get(0), action);
		Webkeywords.instance().verifyElementDisplayed(driver, getElementBasedOnFlag(testCaseDataSd.get("LAST_NAME_VERIFY").get(0),columnHeader,tableName,"Last Name"), testCaseDataSd.get("LAST_NAME_VERIFY").get(0), action);
		Webkeywords.instance().verifyElementDisplayed(driver, getElementBasedOnFlag(testCaseDataSd.get("COLLATERAL_TYPE_VERIFY").get(0),columnHeader,tableName,"Collateral Type"), testCaseDataSd.get("COLLATERAL_TYPE_VERIFY").get(0), action);
		Webkeywords.instance().verifyElementDisplayed(driver, getElementBasedOnFlag(testCaseDataSd.get("ROLE_VERIFY").get(0),columnHeader,tableName,"Role"), testCaseDataSd.get("ROLE_VERIFY").get(0), action);
		Webkeywords.instance().verifyElementDisplayed(driver, getElementBasedOnFlag(testCaseDataSd.get("END_DATE_VERIFY").get(0),columnHeader,tableName,"End Date"), testCaseDataSd.get("END_DATE_VERIFY").get(0), action);
	}
	
	public void navigateToCaseFolioPersonId(String folioPersonId,String scriptIteration, String pomIteration){
		PageDetails action = new PageDetails();
		action.setPageActionName("Navigate to Folio Person Id");
		action.setPageActionDescription("Navigate to Person Tribal Id");
		
		Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(), TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
		WebElement folioPersonLinkXpath = driver.findElement(By.xpath(format(folioPersonIdLink,folioPersonId)));
		Webkeywords.instance().waitElementToBeVisible(driver, folioPersonLinkXpath);
		Webkeywords.instance().waitElementClickable(driver, folioPersonLinkXpath);
		Webkeywords.instance().jsClick(driver, folioPersonLinkXpath, testCaseDataSd.get("FOLIO_PERSON_ID_LINK").get(0),action);	
		Webkeywords.instance().waitElementToBeVisible(driver, genericLocators.textOnPage(driver,"Information", "" ));
	}
	
	public void navigateToCaseFolioPersonName(String folioPersonName,String scriptIteration, String pomIteration){
		PageDetails action = new PageDetails();
		action.setPageActionName("Navigate to Folio Person Name");
		action.setPageActionDescription("Navigate to Person Tribal Name");
		
		Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(), TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
		WebElement folioPersonLinkXpath = driver.findElement(By.xpath(format(folioPersonValidatedName,folioPersonName)));
		Webkeywords.instance().waitElementToBeVisible(driver, folioPersonLinkXpath);
		Webkeywords.instance().waitElementClickable(driver, folioPersonLinkXpath);
		Webkeywords.instance().jsClick(driver, folioPersonLinkXpath, testCaseDataSd.get("FOLIO_PERSON_NAME_LINK").get(0),action);	
		Webkeywords.instance().waitElementToBeVisible(driver, genericLocators.textOnPage(driver,"Person Information", "" ));
	}
	
	public void navigateToCaseFolioPersonAllegationsTab(String scriptIteration, String pomIteration){
		PageDetails action = new PageDetails();
		action.setPageActionName("Navigate to Case Folio Persons Allegations Tab");
		action.setPageActionDescription("Navigate to Case Folio Persons Allegations Tab");
		
		Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(), TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
		String personAllegationTab = testCaseDataSd.get("ALLEGATIONS_TAB").get(0);
		Webkeywords.instance().click(driver, genericLocators.link(driver, "Allegations", personAllegationTab),personAllegationTab, action);
	}

	public void navigateToAuditHistory( String scriptIteration, String pomIteration){
		PageDetails action = new PageDetails();
		
		action.setPageActionName("Navigate to Audit History");
		action.setPageActionDescription("Navigate to Audit History");
		
		Map<String, ArrayList<String>> testCaseDataSd = util.getScreenTCData(screenName,
				testCaseParam.getTestNGTestMethodName(), TestRunSettings.getTestDataPath(),
				TestRunSettings.getTestDataMappingFileName(), TestRunSettings.getTestDataMappingSheetNameSd(),
				scriptIteration, pomIteration);

        String auditHistory =testCaseDataSd.get("AUDIT_HISTORY_TB").get(0);			
		Webkeywords.instance().click(driver, genericLocators.link(driver, "Audit History", auditHistory), auditHistory,
				 action);    
	}
	

	public void verifyAuditHistoryHeaderColumnsInTable(String tableName, String scriptIteration, String pomIteration) {
		PageDetails action = new PageDetails();
		
		action.setPageActionName("Verify Audit History header columns in Table");
		action.setPageActionDescription("Verify Audit History header columns in Table");
			
		Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(), TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);

		Webkeywords.instance().verifyElementDisplayed(driver, getElementBasedOnFlag(testCaseDataSd.get("DATE_VERIFY").get(0),columnHeader,tableName,"Date"), testCaseDataSd.get("DATE_VERIFY").get(0), action);
		Webkeywords.instance().verifyElementDisplayed(driver, getElementBasedOnFlag(testCaseDataSd.get("FIELD_VERIFY").get(0),columnHeader,tableName,"Field"), testCaseDataSd.get("FIELD_VERIFY").get(0), action);
		Webkeywords.instance().verifyElementDisplayed(driver, getElementBasedOnFlag(testCaseDataSd.get("USER_VERIFY").get(0),columnHeader,tableName,"User"), testCaseDataSd.get("USER_VERIFY").get(0), action);
		Webkeywords.instance().verifyElementDisplayed(driver, getElementBasedOnFlag(testCaseDataSd.get("ORIGINAL_VALUE_VERIFY").get(0),columnHeader,tableName,"Original Value"), testCaseDataSd.get("ORIGINAL_VALUE_VERIFY").get(0), action);
		Webkeywords.instance().verifyElementDisplayed(driver, getElementBasedOnFlag(testCaseDataSd.get("NEW_VALUE_VERIFY").get(0),columnHeader,tableName,"New Value"), testCaseDataSd.get("NEW_VALUE_VERIFY").get(0), action);
	}

	public void verifyFolioPersonsInCase(String scriptIteration,String pomIteration)  {
		PageDetails action = new PageDetails();
		
		action.setPageActionName("Verify Folio Persons in Case");
		action.setPageActionDescription("Verify Folio Persons in Case");
		Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(), TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);

		List<String> folioPersonNamesList = new ArrayList<>();
		List<String> folioPersonRolesList = new ArrayList<>();
		CaseDetails caseDetails = new CaseDetails(driver);
		caseDetails.navigateToCaseDetails(scriptIteration,  SalesforceConstants.POMITERATION1);
		caseDetails.navigateToOriginatingInvestigation(scriptIteration,  SalesforceConstants.POMITERATION1);
		Person folioPerson = new Person(driver);	
	    folioPerson.navigateToFolioPersonsTab(scriptIteration,  SalesforceConstants.POMITERATION1);
		folioPersonNamesList = folioPerson.getFolioPersonDetails().get(1);
		folioPersonRolesList = getCaseSpecificRoleNames(folioPerson.getFolioPersonDetails().get(2));

	    SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.INV_CASE);
		navigateToCaseFolioPersons(scriptIteration, SalesforceConstants.POMITERATION1);
        for (int i = 0; i<folioPersonNamesList.size() ; i++) {
        	Webkeywords.instance().verifyElementDisplayed(driver, getElementBasedOnFlag(testCaseDataSd.get("FOLIO_PERSONNAMES_VERIFY").get(0),folioPersonValidatedName,folioPersonNamesList.get(i)), testCaseDataSd.get("FOLIO_PERSONNAMES_VERIFY").get(0), action);
        	Webkeywords.instance().verifyElementDisplayed(driver, getElementBasedOnFlag(testCaseDataSd.get("FOLIO_PERSONROLES_VERIFY").get(0),folioPersonRole,folioPersonRolesList.get(i)), testCaseDataSd.get("FOLIO_PERSONROLES_VERIFY").get(0), action);
        }
	}
	
	public void verifyScreeningPeronInFolio(String pomIteration)  {
		PageDetails action = new PageDetails();
		
		action.setPageActionName("Verify Screening Person in Folio");
		action.setPageActionDescription("Verify Screening Person in Folio");
		
		String actualScreeningPersonName = SalesforceConstants.getConstantValue("personName"+pomIteration);
	    String formatedXpath = format(folioPersonValidatedName,actualScreeningPersonName);
		WebElement scpIdXpath = driver.findElement(By.xpath(formatedXpath));
		String expectedFolioPersonName = scpIdXpath.getAttribute("title");

		Assert.assertEquals(actualScreeningPersonName, expectedFolioPersonName);				
	}

	public WebElement getElementBasedOnFlag(String flag, String columnHeaderXpath, String tableName, String columnName) {
		if(!(flag.equalsIgnoreCase("n/a"))) {
			return driver.findElement(By.xpath(format(columnHeaderXpath,tableName,columnName)));
		}
		else
			return null;
	}
	
	private WebElement getElementBasedOnFlag(String flag, String xpath, String name) {
		if(!(flag.equalsIgnoreCase("n/a"))) {
			return driver.findElement(By.xpath(format(xpath,name)));
		}
		else
			return null;
	}
	
	private List<String> getCaseSpecificRoleNames(List<String> folioPersonRoleList) {
		List<String> caseSpecificPersonRoleList = new ArrayList<>();
		int victimCount = 0;
        // Remove "alleged" and process names
        for (String role : folioPersonRoleList) {
            String modifiedRole = role.replace("Alleged ", ""); // Remove "alleged"
            if (modifiedRole.equals("Victim")) {
                victimCount++;
                if (victimCount == 1) {
                	modifiedRole = "Focus Child"; // Rename first victim
                }
            }
            caseSpecificPersonRoleList.add(modifiedRole);
        }
        return caseSpecificPersonRoleList;
	}
	
	public List<List<String>> getCaseFolioPersonDetails()  {
		PageDetails action = new PageDetails();
		action.setPageActionName("Get Case Folio Person Details");
		action.setPageActionDescription("Get Case Person Details");
	
		List<String> personIdsList= new ArrayList<>();
		List<String> personNamesList = new ArrayList<>();
		List<String> personRolesList = new ArrayList<>();
		Map<String, String[]> casePersonsMap = new HashMap<>();
		String personRole=null;
		String personId=null;
		String personName=null;
		String key = "";
		int victimCount = 1;
		int perpetratorCount = 1;
		int collateralCount = 1;
		int identifiedParentCount = 1;
		int identifiedLegalGuardianCount = 1;
		int identifiedIndianCustodianCount = 1;
		int parentCount = 1;
		int legalGuardianCount = 1;
		int indianCustodianCount = 1;
		int siblingCount = 1;
		int focusChildCount = 1;
				
		for (int i = 0; i < casePersonIds.size(); i++) {
			personIdsList.add(casePersonIds.get(i).getText());
			SalesforceConstants.setConstantValue("CP_ID_"+(i+1),casePersonIds.get(i).getText());
        }
		for (int i = 0; i < casePersonNames.size(); i++) {
			personNamesList.add(casePersonNames.get(i).getText());
			SalesforceConstants.setConstantValue("CP_NAME_"+(i+1),casePersonNames.get(i).getText());
        }
		for (int i = 0; i < casePersonRoles.size(); i++) {
			personRolesList.add(casePersonRoles.get(i).getText());
			SalesforceConstants.setConstantValue("CP_ROLE_"+(i+1), casePersonRoles.get(i).getText());
		}
		
		for (int i = 0; i < casePersonIds.size(); i++) {
			personId = casePersonIds.get(i).getText();
			personRole = casePersonRoles.get(i).getText();
			personName = casePersonNames.get(i).getText();
		
            if (personRole.equals("Victim")) {
                key = "Victim" + victimCount++;
            }else if (personRole.equals("Perpetrator")) {
                key = "Perpetrator" + perpetratorCount++;
            }else if (personRole.equals("Collateral")) {
                key = "Collateral" + collateralCount++;
            }else if (personRole.equals("Focus Child")) {
                key = "FocusChild" + focusChildCount++;
            }else if (personRole.equals("Identified Parent")) {
                key = "IdentifiedParent" + identifiedParentCount++;
            }else if (personRole.equals("Identified Legal Guardian")) {
                key = "IdentifiedLegalGuardian" + identifiedLegalGuardianCount++;
            }else if (personRole.equals("Identified Indian Custodian")) {
                key = "IdentifiedIndianCustodian" + identifiedIndianCustodianCount++;
            }else if (personRole.equals("Parent")) {
                key = "Parent" + parentCount++;
            }else if (personRole.equals("Legal Guardian")) {
                key = "LegalGuardian" + legalGuardianCount++;
            }else if (personRole.equals("Indian Custodian")) {
                key = "IndianCustodian" + indianCustodianCount++;
            }else if (personRole.equals("Sibling")) {
                key = "Sibling" + siblingCount++;
            }
            
            if (!key.isEmpty()) {
            	casePersonsMap.put(key, new String[]{personId, personName});
            }
        }
    	SalesforceConstants.setObjectValue("CASE_PERSON_MAP",casePersonsMap);

		List<List<String>> casePersonsList = new ArrayList<>();
		casePersonsList.add(personIdsList);
		casePersonsList.add(personNamesList);
		casePersonsList.add(personRolesList);
       	return casePersonsList;	
	}
	
	public void navigateToInvCaseFolioPersons( String scriptIteration, String pomIteration){
		PageDetails action = new PageDetails();
		
		action.setPageActionName("Navigate to Case Folio Persons");
		action.setPageActionDescription("Navigate to Case Folio Persons");
		
		Map<String, ArrayList<String>> testCaseDataSd = util.getScreenTCData(screenName,
				testCaseParam.getTestNGTestMethodName(), TestRunSettings.getTestDataPath(),
				TestRunSettings.getTestDataMappingFileName(), TestRunSettings.getTestDataMappingSheetNameSd(),
				scriptIteration, pomIteration);

		String personsTabFolio = testCaseDataSd.get("FOLIO_PERSONS_TAB").get(0);
		Webkeywords.instance().click(driver, genericLocators.button(driver, "Persons", personsTabFolio),
				personsTabFolio, action);
		Webkeywords.instance().pause();
		Webkeywords.instance().scrollUpPageToTheTop(driver);
		Webkeywords.instance().pauseDelay();
	}
}


