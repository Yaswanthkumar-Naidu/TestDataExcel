package cares.cwds.salesforce.pom.courts;

import static java.lang.String.format;

import java.util.ArrayList;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cares.cwds.salesforce.constants.ModuleConstants;
import cares.cwds.salesforce.constants.SalesforceConstants;
import cares.cwds.salesforce.constants.ScreenConstants;
import cares.cwds.salesforce.utilities.common.TestRunSettings;
import cares.cwds.salesforce.utilities.common.Util;
import cares.cwds.salesforce.utilities.reports.common.ReportCommon;
import cares.cwds.salesforce.utilities.reports.common.ScreenshotCommon;
import cares.cwds.salesforce.utilities.reports.extentmodel.PageDetails;
import cares.cwds.salesforce.utilities.reports.model.TestCaseParam;
import cares.cwds.salesforce.utilities.testng.TestNGCommon;
import cares.cwds.salesforce.utilities.web.CommonOperations;
import cares.cwds.salesforce.utilities.web.GenericLocators;
import cares.cwds.salesforce.utilities.web.SalesforceCommon;
import cares.cwds.salesforce.utilities.web.Webkeywords;

public class CourtMinuteOrder {

	private WebDriver driver;
	ReportCommon exceptionDetails = new ReportCommon();
	Util util = new Util();
	GenericLocators genericLocators = null;
	TestNGCommon testngCommon = new TestNGCommon();
	TestCaseParam testCaseParam = (TestCaseParam) testngCommon.getTestAttribute("testCaseParam");
	String moduleName = ModuleConstants.COURTS;
	String screenName = ScreenConstants.COURTMINUTEORDER;
	private static final Logger logger = LoggerFactory.getLogger(Webkeywords.class.getName());
	
	private static final String COURTMINUTEORDERS = "Court Minute Orders";

	public CourtMinuteOrder(){ }

	public CourtMinuteOrder(WebDriver wDriver) 
	{
		initializePage(wDriver);
	}

	public void initializePage(WebDriver wDriver) 
	{
		driver = wDriver;
		PageFactory.initElements(driver, this);
		ReportCommon testStepLogDetails = new ReportCommon(); 
		testStepLogDetails.logModuleAndScreenDetails(moduleName, screenName);
		genericLocators = new GenericLocators(wDriver);

	}

	@FindBy(how = How.XPATH, using = "(//label[text()='Due Date to Supervisor']/../../following-sibling::lightning-input//input)[2]")
	public WebElement immediateActionForthwithOrderDueDate;

	@FindBy(how = How.XPATH, using = "//button[text()='New']")
	public WebElement newBtn;
	
	@FindBy(how = How.XPATH, using = "//c-kreator-input-selection-radio[@data-lwc-id='Court_Minute_Order__c|Court_Ordered_Special_program__c']//span[@class='slds-radio'][1]//span[1]")
	public WebElement yesRDbtn;

	@FindBy(how = How.XPATH, using = "//c-kreator-input-selection-radio[@data-lwc-id='Court_Minute_Order__c|Court_Ordered_Special_program__c']//span[@class='slds-radio'][2]//span[1]")
	public WebElement noRDbtn;

	String courtMinuteOrderRecord = "//span[text()='%s']//ancestor::a";
	
	public void navigateToCourtMinuteOrder(String scriptIteration, String pomIteration)  {
		PageDetails action = new PageDetails();
		action.setPageActionName("Navigate to Court Minute Order");
		action.setPageActionDescription("Navigate to Court Minute Order");

		Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(),
				TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);			
	
		String courtMinuteOrderTabTD = testCaseDataSd.get("COURT_MINUTE_ORDER_TAB").get(0);
		Webkeywords.instance().waitElementToBeVisible(driver,  genericLocators.link(driver, COURTMINUTEORDERS,courtMinuteOrderTabTD));
		Webkeywords.instance().click(driver, genericLocators.link(driver, COURTMINUTEORDERS,courtMinuteOrderTabTD), courtMinuteOrderTabTD, action);
		Webkeywords.instance().pause();

		ScreenshotCommon.captureFullPageScreenShot(driver, moduleName+"-"+screenName);

	}

	public void navigateToCourtMinuteOrderPage(String scriptIteration, String pomIteration){

		PageDetails action = new PageDetails();
		action.setPageActionName("Navigate to  Court Minute Order Page");
		action.setPageActionDescription("Navigate to  Court Minute Order Page");

		Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(), TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
	
		Webkeywords.instance().click(driver, genericLocators.button(driver, "New", testCaseDataSd.get("NEW_BTN").get(0)), testCaseDataSd.get("NEW_BTN").get(0),action);
		Webkeywords.instance().pause();
	}



	public void addCourtMinuteOrderPageInformation( String scriptIteration, String pomIteration)  {
		PageDetails action = new PageDetails();
		action.setPageActionName("Add to Court Minute Order Page Information");
		action.setPageActionDescription("Add to Court Minute Order Page Information");

		Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(), TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
	
		Webkeywords.instance().click(driver, genericLocators.textbox(driver, "Select Court Work Item Participant", testCaseDataSd.get("SELECT_COURT_WORK_ITEM_PARTICIPANT").get(0)), testCaseDataSd.get("SELECT_COURT_WORK_ITEM_PARTICIPANT").get(0),action);
        Webkeywords.instance().pauseDelay();
       
		Webkeywords.instance().click(driver, genericLocators.link(driver, SalesforceConstants.getObjectValue("CASE_PERSON_MAP").get("Victim1")[1],testCaseDataSd.get("SELECT_COURT_WORK_ITEM_PARTICIPANT").get(0)),testCaseDataSd.get("SELECT_CHILDREN").get(0),action);
	
		Webkeywords.instance().selectInputDropdownValue(driver,testCaseDataSd.get("SELECT_FINDINGS").get(0),"Select Findings",action);
		Webkeywords.instance().selectInputDropdownValue(driver,testCaseDataSd.get("KEY_ORDERS").get(0),"Key Orders",action);
		Webkeywords.instance().selectInputDropdownValue(driver,testCaseDataSd.get("COURT_ORDER_STATUS").get(0),"Court Order Status",action);
		Webkeywords.instance().selectInputDropdownValue(driver,testCaseDataSd.get("AD_HOC_ACTIVITY_OUTCOME").get(0),"Ad Hoc Activity Outcome",action);


		Webkeywords.instance().click(driver, yesRDbtn,testCaseDataSd.get("YES_COURT_ORDERED_SPECIAL_PROGRAMS").get(0),action);
		Webkeywords.instance().click(driver, noRDbtn,testCaseDataSd.get("NO_COURT_ORDERED_SPECIAL_PROGRAMS").get(0),action);
		Webkeywords.instance().click(driver, genericLocators.radiobutton(driver, "Does the case include Immediate Action/Forthwith Orders?",testCaseDataSd.get("IMMEDIATE_ACTION_FORTHWITH_ORDERS").get(0)),testCaseDataSd.get("IMMEDIATE_ACTION_FORTHWITH_ORDERS").get(0),action);

		Webkeywords.instance().setDateText(driver, immediateActionForthwithOrderDueDate, CommonOperations.getDate("M/d/yyyy", testCaseDataSd.get("IMMEDIATE_ACTION_FORTHWITH_ORDER_DUE_DATE").get(0)), action);		

		Webkeywords.instance().setText(driver, genericLocators.textbox(driver, "Additional Court Orders",testCaseDataSd.get("ADDITIONAL_COURT_ORDERS").get(0)), util.getRandom(testCaseDataSd.get("ADDITIONAL_COURT_ORDERS").get(0)), action);	

		Webkeywords.instance().click(driver, genericLocators.button(driver, "Save",testCaseDataSd.get("SAVE_BTN").get(0)),testCaseDataSd.get("SAVE_BTN").get(0),action);
		Webkeywords.instance().pause();
	}
	public void validateNewBtn(){

		PageDetails action = new PageDetails();
		action.setPageActionName("Validate New Button");
		action.setPageActionDescription("Validate New Button");

		boolean status = Webkeywords.instance().isElementVisible(newBtn);
		if(status) {
			logger.info("The Element is displayed in the application");
		}else {
			logger.info("The Element is not displayed in the application");
     	}
	}
	
	public void navigateToExistingCourtMinuteOrderRecord(String scriptIteration, String pomIteration){
		PageDetails action = new PageDetails();
		action.setPageActionName("Navigate to Existing CourtMinuteOrder Record");
		action.setPageActionDescription("Navigate to Existing CourtMinuteOrder Record");
		
			Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(), TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
			Webkeywords.instance().scrollDownToPage(driver);
			String courtMinuteOrder = SalesforceConstants.getConstantValue(testCaseDataSd.get("COURT_MINUTE_ORDER_ID").get(0));
			String formatedXpath = format(courtMinuteOrderRecord, courtMinuteOrder);
			Webkeywords.instance().pause();
			WebElement placementOptionIdXpath = driver.findElement(By.xpath(formatedXpath));
			Webkeywords.instance().waitElementClickable(driver, placementOptionIdXpath);
			Webkeywords.instance().jsClick(driver,  placementOptionIdXpath, testCaseDataSd.get("COURT_MINUTE_ORDER_ID").get(0),action);
			Webkeywords.instance().pause();				
	}


}