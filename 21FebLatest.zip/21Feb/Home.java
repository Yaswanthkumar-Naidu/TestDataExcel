package cares.cwds.salesforce.pom;

import static java.lang.String.format;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import cares.cwds.salesforce.constants.ModuleConstants;
import cares.cwds.salesforce.constants.SalesforceConstants;
import cares.cwds.salesforce.constants.ScreenConstants;
import cares.cwds.salesforce.utilities.common.TestRunSettings;
import cares.cwds.salesforce.utilities.common.Util;
import cares.cwds.salesforce.utilities.reports.common.ReportCommon;
import cares.cwds.salesforce.utilities.reports.extentmodel.PageDetails;
import cares.cwds.salesforce.utilities.reports.model.TestCaseParam;
import cares.cwds.salesforce.utilities.testng.TestNGCommon;
import cares.cwds.salesforce.utilities.web.GenericLocators;
import cares.cwds.salesforce.utilities.web.SalesforceCommon;
import cares.cwds.salesforce.utilities.web.Webkeywords;

public class Home {
	
	private static final Logger logger =LoggerFactory.getLogger(Home.class.getName());
	private static final String SHOW_NAVIGATION_MSG = "Show Navigation Menu";
	private WebDriver driver;
	ReportCommon exceptionDetails = new ReportCommon();
	Util util = new Util();
	GenericLocators genericLocators = null;
	TestNGCommon testngCommon = new TestNGCommon();
	TestCaseParam testCaseParam = (TestCaseParam) testngCommon.getTestAttribute("testCaseParam");

	String moduleName = ModuleConstants.COMMON;
	String screenName = ScreenConstants.HOME;

	
	public Home(){ }
	
	public Home(WebDriver wDriver) 
	{
		initializePage(wDriver);
	}
	
	public void initializePage(WebDriver wDriver) 
	    {
	    	 driver = wDriver;
	         PageFactory.initElements(driver, this);
	         ReportCommon testStepLogDetails = new ReportCommon(); 
	         testStepLogDetails.logModuleAndScreenDetails(moduleName, screenName);
	         genericLocators = new GenericLocators(wDriver);
	    }
	
	
	@FindBy(how = How.XPATH, using = "//button[contains(@class,'slds-global-actions__notifications slds-global-actions__item-action')]")
	public WebElement bellIcon;

	@FindBy(how = How.XPATH, using = "//li[@class='notification-row notification-unread unsNotificationsListRow']/a/div/div/h3[@class='notification-text-title']")
	public List<WebElement> notificationTitlesList;

	@FindBy(how = How.XPATH, using = "//li[@class='notification-row notification-unread unsNotificationsListRow']/a/div/div/span[@class='notification-text uiOutputText']")
	public List<WebElement> notificationMessagesList;

	@FindBy(how = How.XPATH, using = "//div[@data-se='app-card-container']/a")
	public WebElement selectApp;
	
	@FindBy(how = How.XPATH, using = "//div/span[contains(text(),'CWS-CARES')]")
	public WebElement txtcares;
	
	@FindBy(how = How.XPATH, using = "//div[@data-aura-class='navexAppNavMenu']")
	public WebElement appNavMenu;
	
	@FindBy(how = How.XPATH, using = "//*[@role='menu'][@aria-label='Navigation Menu']")
	public WebElement appNavMenuContainerList;
	
	@FindBy(how = How.XPATH, using = "//*[contains(text(),'Search')]//parent::button")
	public WebElement searchRecord;
	
	@FindBy(how = How.XPATH, using = "//span[text()='Recent Records']//ancestor::article//div[2]//ul")
	public WebElement recentRecords;
	
	String clickRecord = "//span[@title='%s']//parent::div/span";
	
	String pageName = "//span[contains(@class,'slds-listbox__option')][text()='%s']";
	
	String quickLink = "//*[contains(text(),'Quick Links')]//ancestor::lightning-card//button[text()='%s']";
	
	String viewButton  = "//*[contains(text(),'%s')]//ancestor::lightning-card//button[text()='%s']";
	
    @FindBy(how = How.XPATH, using = "//button[contains(@title,'Close')]")
	public WebElement closeButton;
    
    @FindBy(how = How.XPATH, using ="//input[@data-value='Search: All']//ancestor::lightning-grouped-combobox/../following::input[@type='search']")
    public WebElement searchTextField;
    
    @FindBy(how = How.XPATH, using ="//input[@placeholder='Search this list...']")
    public WebElement innerSearch;
    
    @FindBy(how = How.XPATH, using ="//a[@data-refid='recordId']")
    public WebElement recordID;
    
    @FindBy(xpath = "//span[text()='Close']/..]")
	WebElement warningCloseBtn;
  
	@FindBy(xpath = "//div[@data-key='warning']")
	WebElement warningPopup;
    
	@FindBy(xpath = "//table[@aria-label='Current Case Assignments']//tbody//tr/th//a")
	WebElement currentCaseIdLink;
	
	@FindBy(xpath = "//table[@aria-label='Current Task Assignments']//tbody//tr/th//a")
	WebElement currentTaskIdLink;
	
	@FindBy(how = How.XPATH, using = "//*[@title='Case Type']/..//lightning-formatted-text")
	public WebElement caseType;
	
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'windowViewMode-maximized')]//*[@title='Related To']/..//a")
	public WebElement relatedTo;
	
	@FindBy(how = How.XPATH, using = "//*[@title='Task ID']/..//span")
	public WebElement taskId;
	
	@FindBy(how = How.XPATH, using = "//records-entity-label[text()='CARES Item']//parent::slot//following::slot//lightning-formatted-text[@slot='primaryField']")
	public WebElement folioRecordName;
	
	@FindBy(how = How.XPATH, using ="//div[text()='Task']//parent::h1//span")
	public WebElement childNotification; 
	
    private String notificationTitle = "//div[@class='unsNotificationsPanel']//div[@class='listContainer scrollable']//div[@class='notification-content']//*[text()='%s']";
    private String notificationMessage = "//div[@class='unsNotificationsPanel']//div[@class='listContainer scrollable']//div[@class='notification-content']//span[contains(normalize-space(),'%s')]";
	String columnHeader = "//table[@aria-label='%s']/thead/tr/th[@*='%s']";
	private String courtNotificationMessage = "//div[@class='unsNotificationsPanel']//div[@class='listContainer scrollable']//div[@class='notification-content']//span[text()='%s']";

    
    //pageTitle should match the app menu item name on the Home page
	public void navigateToAppMenuPage(String pageTitle,String scriptIteration, String pomIteration) {
		PageDetails action = new PageDetails();

		action.setPageActionName("Navigate to App Menu Page");
		action.setPageActionDescription("Navigate to App Menu Page");
			Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(), TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
			String testDataPageTitle = null;
			Webkeywords.instance().pause();
			Webkeywords.instance().pause();
			Webkeywords.instance().closeAllOpenTabs(driver, closeButton);	
			Webkeywords.instance().waitElementToBeVisible(driver, appNavMenu);
			Webkeywords.instance().click(driver, appNavMenu,testCaseDataSd.get("APP_NAV_MENU").get(0), action);
			Webkeywords.instance().waitElementToBeVisible(driver, appNavMenuContainerList);
			WebElement page = driver.findElement(By.xpath(format(pageName,pageTitle)));
			Webkeywords.instance().scrollIntoViewElement(driver,page);
			testDataPageTitle = (pageTitle.toUpperCase()).replace(" ","_");
			if(pageTitle.equalsIgnoreCase("Service Names / Evidence Based Practices"))
				testDataPageTitle = "SERVICE_NAMES";
			Webkeywords.instance().click(driver, page,testCaseDataSd.get(testDataPageTitle).get(0), action);
			
			}
	
	//name should match the quick link on the Home page
	public void navigateToQuickLinkInHome(String name, String scriptIteration, String pomIteration) {
		PageDetails action = new PageDetails();
		action.setPageActionName("Navigate to Homepage QuickLink");
		action.setPageActionDescription("Navigate to Homepage QuickLink");	
			String testDataName=null;
			Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(), TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
			testDataName = (name.toUpperCase()).replace(" ","_");
			Webkeywords.instance().click(driver, driver.findElement(By.xpath(format(quickLink,name))),testCaseDataSd.get(testDataName).get(0), action);
	}
	
	public void navigateToViewAssessmentsInHome(String scriptIteration, String pomIteration) {
		PageDetails action = new PageDetails();
		action.setPageActionName("Navigate to View Assessments in Home");
		action.setPageActionDescription("Navigate to View Assessments in Home");	
		Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(), TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
		Webkeywords.instance().click(driver, driver.findElement(By.xpath(format(viewButton,"Assessments","View"))),testCaseDataSd.get("ASSESSMENTS_VIEW_BTN").get(0), action);
		Webkeywords.instance().pause();
	}
	
	public void navigateToViewContactNotesInHome(String scriptIteration, String pomIteration) {
		PageDetails action = new PageDetails();
		action.setPageActionName("Navigate to View Contact Notes in Home");
		action.setPageActionDescription("Navigate to View Contact Notes in Home");	
		Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(), TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
		Webkeywords.instance().click(driver, driver.findElement(By.xpath(format(viewButton,"Contact Notes","View"))),testCaseDataSd.get("CONTACTNOTES_VIEW_BTN").get(0), action);
		Webkeywords.instance().pause();
	}
	
	public void navigateToCasesWorkItemInHomeAssessments(String scriptIteration, String pomIteration) {
		PageDetails action = new PageDetails();
		action.setPageActionName("Navigate to Cases WorkItem in Home Assessments");
		action.setPageActionDescription("Navigate to Cases WorkItem in Home Assessments");	
		
		Map<String, ArrayList<String>> testCaseDataSd = util.getScreenTCData(screenName,
				testCaseParam.getTestNGTestMethodName(), TestRunSettings.getTestDataPath(),
				TestRunSettings.getTestDataMappingFileName(), TestRunSettings.getTestDataMappingSheetNameSd(),
				scriptIteration, pomIteration);

		String casesTabTD = testCaseDataSd.get("CASES_TAB").get(0);
		Webkeywords.instance().click(driver, genericLocators.link(driver, "Cases", casesTabTD), casesTabTD, action);
	}
	
	public void navigateToTasksWorkItemInHomeAssessments(String scriptIteration, String pomIteration) {
		PageDetails action = new PageDetails();
		action.setPageActionName("Navigate to Tasks WorkItem in Home Assessments");
		action.setPageActionDescription("Navigate to Tasks WorkItem in Home Assessments");	
		
		Map<String, ArrayList<String>> testCaseDataSd = util.getScreenTCData(screenName,
				testCaseParam.getTestNGTestMethodName(), TestRunSettings.getTestDataPath(),
				TestRunSettings.getTestDataMappingFileName(), TestRunSettings.getTestDataMappingSheetNameSd(),
				scriptIteration, pomIteration);

		String tasksTabTD = testCaseDataSd.get("TASKS_TAB").get(0);
		Webkeywords.instance().click(driver, genericLocators.link(driver, "Tasks", tasksTabTD), tasksTabTD, action);
	}

	public void verifyNotificationMessage() {
		PageDetails action = new PageDetails();
		action.setPageActionName("Verify Notification");
		action.setPageActionDescription("Verify Notification");
		Webkeywords.instance().click(driver, bellIcon,"", action);
	}
	
	public void verifyNotification(String expectedTitle, String expectedMessage){
		PageDetails action = new PageDetails();
		action.setPageActionName("Verify Bell Notification Message");
		action.setPageActionDescription("Verify Bell Notification Message");

		Webkeywords.instance().waitElementToBeVisible(driver, bellIcon);
		Webkeywords.instance().click(driver, bellIcon,"", action);
		Webkeywords.instance().verifyElementDisplayed(driver, driver.findElement(By.xpath(format(notificationTitle,expectedTitle))), "", action);
		Webkeywords.instance().verifyElementDisplayed(driver, driver.findElement(By.xpath(format(notificationMessage,expectedMessage))), "", action);
		Webkeywords.instance().click(driver, bellIcon,"", action);
	}
	
/////////////////////////////This method is already covered in the above method navigateToAppMenuPage() and can be removed///////////////////////////////
	public void selectLinkFromNavigationMenue(String scriptIteration, String pomIteration, String navigatorMenue){
		PageDetails action = new PageDetails();
		action.setPageActionName(SHOW_NAVIGATION_MSG);
		action.setPageActionDescription(SHOW_NAVIGATION_MSG);

		Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(),
				TestRunSettings.getTestDataMappingFileName(),TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
		
		Webkeywords.instance().click(driver, genericLocators.button(driver, SHOW_NAVIGATION_MSG,testCaseDataSd.get("SHOWNAVIGATIONMENUE").get(0)), testCaseDataSd.get("SHOWNAVIGATIONMENUE").get(0), action);
		switch (navigatorMenue) {
		case "Organizations":
			Webkeywords.instance().click(driver, genericLocators.button(driver, "Organizations",testCaseDataSd.get("ORGANIZATIONS").get(0)), testCaseDataSd.get("ORGANIZATIONS").get(0), action);
			break;
		case "Provider Search":
			Webkeywords.instance().click(driver, genericLocators.button(driver, "Provider Search",testCaseDataSd.get("PROVIDERSEARCH").get(0)), testCaseDataSd.get("PROVIDERSEARCH").get(0), action);
			break;
		case "Screenings":
			Webkeywords.instance().click(driver, genericLocators.button(driver, "Screenings",testCaseDataSd.get("SCREENINGS").get(0)), testCaseDataSd.get("testCaseDataSd.get(\"RECALL\").get(0)").get(0), action);
			break;
		case "Home":
			Webkeywords.instance().click(driver, genericLocators.button(driver, "Home",testCaseDataSd.get("HOME_TAB").get(0)), testCaseDataSd.get("HOME_TAB").get(0), action);
			break;
		case "Focused Search":
			Webkeywords.instance().click(driver, genericLocators.button(driver, "Focused Search",testCaseDataSd.get("FOCUSED_SEARCH_TAB").get(0)), testCaseDataSd.get("FOCUSED_SEARCH_TAB").get(0), action);
			break;
		case "Person Search":
			Webkeywords.instance().click(driver, genericLocators.button(driver, "Person Search",testCaseDataSd.get("PERSON_SEARCH").get(0)), testCaseDataSd.get("PERSON_SEARCH").get(0), action);
			break;
			default:
				break;
			}
	}
	
	public void clickOnNotificationForApproval(String recordType, String scriptIteration, String pomIteration){
		PageDetails action = new PageDetails();
		action.setPageActionName("Click Bell Notification Item");
		action.setPageActionDescription("Click Bell Notification Item");
		
		WebElement notificationBell = null;
		WebElement scrIdnotification = null;
		String id;
		notificationBell = Webkeywords.instance().waitAndReturnWebElement(driver,By.xpath("//button[contains(@class,'slds-global-actions__notifications slds-global-actions__item-action')]"));
		Webkeywords.instance().waitElementClickable(driver, notificationBell);
		Webkeywords.instance().click(driver, notificationBell,"", action);
		switch (recordType.toLowerCase()) {
		case "scr_id":
			id = SalesforceConstants.getConstantValue(recordType+pomIteration);
			scrIdnotification = Webkeywords.instance().waitAndReturnWebElement(driver,By.xpath("//div/span[contains(text(),'Screening ID: " + id + "')]"));
			Webkeywords.instance().waitElementClickable(driver, scrIdnotification);
			Map<String, ArrayList<String>>	testCaseDataSd1 = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(), TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
			Webkeywords.instance().click(driver, scrIdnotification,testCaseDataSd1.get("SCR_BELL_NOTIFICATION").get(0), action);
			return;
		case "folio_id":
			id = SalesforceConstants.getConstantValue(recordType+pomIteration);
			WebElement folionotification = driver.findElement(By.xpath("//div/span[contains(text(),'CARES Item Ref.: " + id.replaceAll("REF", "FOL") + "')]"));
			Webkeywords.instance().waitElementClickable(driver, folionotification);
			Map<String, ArrayList<String>>	testCaseDataSd2 = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(), TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
			Webkeywords.instance().click(driver, folionotification,testCaseDataSd2.get("SCR_BELL_NOTIFICATION").get(0), action);
			return;
		case "inv_case_id":
			id = SalesforceConstants.getConstantValue(recordType+pomIteration);
			WebElement invCaseNotification = driver.findElement(By.xpath("//div/span[contains(text(),'Folio Ref.: " + id + "')]"));
			Webkeywords.instance().waitElementClickable(driver, invCaseNotification);
			Map<String, ArrayList<String>>	testCaseDataSd3 = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(), TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
			Webkeywords.instance().click(driver, invCaseNotification,testCaseDataSd3.get("BELL_NOTIFICATION").get(0), action);
			return;
		case "non_inv_case_id":
			id = SalesforceConstants.getConstantValue(recordType+pomIteration);
			WebElement nonInvCaseNotification = driver.findElement(By.xpath("//div/span[contains(text(),'CARES Item Ref.: " + id + "')]"));
			Webkeywords.instance().waitElementClickable(driver, nonInvCaseNotification);
			Map<String, ArrayList<String>>	testCaseDataSd4 = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(), TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
			Webkeywords.instance().click(driver, nonInvCaseNotification,testCaseDataSd4.get("BELL_NOTIFICATION").get(0), action);
			return;
		case "family transfer id":
			id = SalesforceConstants.getConstantValue(recordType);
			WebElement ftrnotification = driver.findElement(By.xpath("//div/span[contains(text(),'Family Transfer ID: " + id + "')]"));
			Webkeywords.instance().waitElementClickable(driver, ftrnotification);			
			Map<String, ArrayList<String>>	testCaseDataSd5 = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(), TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
			Webkeywords.instance().click(driver, ftrnotification,testCaseDataSd5.get("BELL_NOTIFICATION").get(0), action);

			return;
		case "court work item id":
			WebElement courtnotification = driver.findElement(By.xpath("//li[1]//div/span[contains(text(),'Court Work Item ID:')]"));
			Webkeywords.instance().waitElementClickable(driver, courtnotification);
			Webkeywords.instance().click(driver, courtnotification,"", action);
			return;
		default:
			logger.error("Record type name not found in click notification");
		}

	}

	public void searchRecordMethod (String scriptIteration, String pomIteration)  {
		PageDetails action = new PageDetails();

		action.setPageActionName("Search Record");
		action.setPageActionDescription("Search Record");
			Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(),
					TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
			String recordId=null;
			recordId=SalesforceConstants.getConstantValue(testCaseDataSd.get("RECORD_ID").get(0));
			if(recordId==null) {
				recordId = SalesforceConstants.getConstantValue("RECORD_ID");
			}
			
			Webkeywords.instance().click(driver,searchRecord ,testCaseDataSd.get("SEARCH").get(0), action);
			Webkeywords.instance().setText(driver,searchTextField,recordId , action);
			Webkeywords.instance().pause();
			WebElement page = driver.findElement(By.xpath(format(clickRecord,recordId))) ;
			Webkeywords.instance().waitElementToBeVisible(driver, page);
			Webkeywords.instance().waitElementClickable(driver, page);
			Webkeywords.instance().waitElementToBeVisible(driver, page);
			Webkeywords.instance().click(driver,page ,recordId, action);
			Webkeywords.instance().pause();
	}
	

	
	public void searchFolioRecord (String scriptIteration, String pomIteration) {
		PageDetails action = new PageDetails();
		action.setPageActionName("Search Folio Record");
		action.setPageActionDescription("Search Folio Record");


			Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(),
					TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
			Webkeywords.instance().pause();
			String recordId = SalesforceConstants.getConstantValue(testCaseDataSd.get("RECORD_ID2").get(0));
			Webkeywords.instance().click(driver,searchRecord ,testCaseDataSd.get("SEARCH").get(0), action);
			Webkeywords.instance().setText(driver,searchTextField,recordId.replace("REF", "FOL") , action);
			Webkeywords.instance().pause();
			WebElement page = driver.findElement(By.xpath(format(clickRecord,recordId.replace("REF", "FOL")))) ;
			Webkeywords.instance().waitElementToBeVisible(driver, page);
			Webkeywords.instance().waitElementClickable(driver, page);
			Webkeywords.instance().waitElementToBeVisible(driver, page);
			Webkeywords.instance().click(driver,page ,recordId.replace("REF", "FOL"), action);
			Webkeywords.instance().pause();
			SalesforceCommon.captureRecordURL(driver,"CASE");
			SalesforceCommon.captureRecordURL(driver,SalesforceConstants.REFERRALURL);
			SalesforceConstants.setConstantValue("RECORD_NAME", folioRecordName.getText());
	}
	
	public void searchPersonRecord (String scriptIteration, String pomIteration) {
		PageDetails action = new PageDetails();
		action.setPageActionName("Search Folio Record");
		action.setPageActionDescription("Search Folio Record");


			Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(),
					TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
			Webkeywords.instance().pause();

			String recordId = "AUTOCarroll AUTOMao";
			Webkeywords.instance().click(driver,searchRecord ,testCaseDataSd.get("SEARCH").get(0), action);
			Webkeywords.instance().setText(driver,searchTextField,recordId , action);
			Webkeywords.instance().pause();
			WebElement page = driver.findElement(By.xpath(format(clickRecord,recordId))) ;
			Webkeywords.instance().waitElementToBeVisible(driver, page);
			Webkeywords.instance().waitElementClickable(driver, page);
			Webkeywords.instance().waitElementToBeVisible(driver, page);
			Webkeywords.instance().click(driver,page ,recordId, action);
			Webkeywords.instance().pause();
			SalesforceCommon.captureRecordURL(driver,"PERSON");

	}


		public void closeAllTabs() {

			PageDetails action = new PageDetails();
			action.setPageActionName("Close All tabs");
			action.setPageActionDescription("Close All tabs");
			
				Webkeywords.instance().closeAllOpenTabs(driver, closeButton);
			
		}
		

		public void searchConstantMethod (String moduleName, String scriptIteration, String pomIteration) {
			PageDetails action = new PageDetails();
			action.setPageActionName("Inner Screening Search Record");
			action.setPageActionDescription("Inner Screening Search Record");
			String recordId = null;
			switch(moduleName) {
			case "Screening":
			case "Screenings":
				recordId = SalesforceConstants.getConstantValue("SCR_ID"+pomIteration);
				SalesforceConstants.setConstantValue("RECORD_ID", recordId);
				Webkeywords.instance().closeAllOpenTabs(driver, closeButton);	
				searchRecordMethod(scriptIteration, pomIteration);
				SalesforceCommon.captureRecordURL(driver, SalesforceConstants.SCREENINGURL);
				break;
			case "Referral":
				recordId = SalesforceConstants.getConstantValue("REF_ID"+pomIteration);
				recordId = recordId.replaceAll("REF", "FOL");
				SalesforceConstants.setConstantValue("RECORD_ID", recordId);
				searchRecordMethod(scriptIteration, pomIteration);
				SalesforceCommon.captureRecordURL(driver, SalesforceConstants.REFERRALURL);
				break;
			case "Case":
				recordId = SalesforceConstants.getConstantValue("CASE_ID"+pomIteration);
				recordId = recordId.replaceAll("CAS", "FOL");
				SalesforceConstants.setConstantValue("RECORD_ID", recordId);
				searchRecordMethod(scriptIteration, pomIteration);
				SalesforceCommon.captureRecordURL(driver, SalesforceConstants.CASEURL);
				break;
			case "Eligibility":
				recordId = SalesforceConstants.getConstantValue("ELIGIBILITY_ID"+pomIteration);
				SalesforceConstants.setConstantValue("RECORD_ID", recordId);
				searchRecordMethod(scriptIteration, pomIteration);
				SalesforceCommon.captureRecordURL(driver, SalesforceConstants.ELIGIBILITYURL);
				break;
			}
		}
		
		public void verifyingHomeCurrentTaskAssignmentsFieldsHeaders (String scriptIteration, String pomIteration) {
			PageDetails action = new PageDetails();
			action.setPageActionName("verifying Current Task Assignments Fields");
			action.setPageActionDescription("verifying Current Task Assignments Fields");
			
			Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(),
						TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
					
			Webkeywords.instance().waitElementToBeVisible(driver, genericLocators.link(driver, "Current Task Assignments",testCaseDataSd.get("CURRENTTASKASSIGNMENT_VERIFY").get(0)));
			Webkeywords.instance().verifyElementDisplayed(driver, genericLocators.link(driver, "Current Task Assignments",testCaseDataSd.get("CURRENTTASKASSIGNMENT_VERIFY").get(0)), testCaseDataSd.get("CURRENTTASKASSIGNMENT_VERIFY").get(0), action);
			Webkeywords.instance().verifyElementDisplayed(driver, genericLocators.columnHeader(driver, "Current Task Assignments" ,"Due Date",testCaseDataSd.get("DUEDATE_VERIFY").get(0)), testCaseDataSd.get("DUEDATE_VERIFY").get(0), action);
			Webkeywords.instance().verifyElementDisplayed(driver, genericLocators.columnHeader(driver, "Current Task Assignments" ,"Subject",testCaseDataSd.get("SUBJECT_VERIFY").get(0)), testCaseDataSd.get("SUBJECT_VERIFY").get(0), action);
			Webkeywords.instance().verifyElementDisplayed(driver, genericLocators.columnHeader(driver, "Current Task Assignments" ,"Related To",testCaseDataSd.get("RELATEDTO_VERIFY").get(0)), testCaseDataSd.get("RELATEDTO_VERIFY").get(0), action);
			Webkeywords.instance().verifyElementDisplayed(driver, genericLocators.columnHeader(driver, "Current Task Assignments" ,"Priority",testCaseDataSd.get("PRIORITY_VERIFY").get(0)), testCaseDataSd.get("PRIORITY_VERIFY").get(0), action);
			Webkeywords.instance().verifyElementDisplayed(driver, genericLocators.columnHeader(driver, "Current Task Assignments" ,"Status",testCaseDataSd.get("STATUS_VERIFY").get(0)), testCaseDataSd.get("STATUS_VERIFY").get(0), action);
			Webkeywords.instance().verifyElementDisplayed(driver, genericLocators.columnHeader(driver, "Current Task Assignments" ,"Source",testCaseDataSd.get("SOURCE_VERIFY").get(0)), testCaseDataSd.get("SOURCE_VERIFY").get(0), action);
		}
		
	public void verifyingHomeCurrentCaseAssignmentsFieldsHeaders (String scriptIteration, String pomIteration) {
		PageDetails action = new PageDetails();
		action.setPageActionName("verifying Current Case Assignments Fields");
		action.setPageActionDescription("verifying Current Case Assignments Fields");
		
		Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(),
					TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
		
		Webkeywords.instance().waitElementToBeVisible(driver, genericLocators.link(driver, "Current Case Assignments",testCaseDataSd.get("CURRENTCASEASSIGNMENT_VERIFY").get(0)));
		Webkeywords.instance().verifyElementDisplayed(driver, genericLocators.link(driver, "Current Case Assignments",testCaseDataSd.get("CURRENTCASEASSIGNMENT_VERIFY").get(0)), testCaseDataSd.get("CURRENTTASKASSIGNMENT_VERIFY").get(0), action);
		Webkeywords.instance().verifyElementDisplayed(driver, getElementBasedOnFlag(testCaseDataSd.get("FOLIOREF_VERIFY").get(0),columnHeader,"Current Case Assignments","Folio Ref."), testCaseDataSd.get("FOLIOREF_VERIFY").get(0), action);
		Webkeywords.instance().verifyElementDisplayed(driver, getElementBasedOnFlag(testCaseDataSd.get("FOLIO_NAME").get(0),columnHeader,"Current Case Assignments","Folio Name"), testCaseDataSd.get("FOLIO_NAME").get(0), action);
		Webkeywords.instance().verifyElementDisplayed(driver, getElementBasedOnFlag(testCaseDataSd.get("CASE_OPEN_DATE_VERIFY").get(0),columnHeader,"Current Case Assignments","Case Open Date"), testCaseDataSd.get("CASE_OPEN_DATE_VERIFY").get(0), action);
		Webkeywords.instance().verifyElementDisplayed(driver, getElementBasedOnFlag(testCaseDataSd.get("CASE_TYPE_VERIFY").get(0),columnHeader,"Current Case Assignments","Case Type"), testCaseDataSd.get("CASE_TYPE_VERIFY").get(0), action);
		Webkeywords.instance().verifyElementDisplayed(driver, getElementBasedOnFlag(testCaseDataSd.get("CASE_SUBTYPE_VERIFY").get(0),columnHeader,"Current Case Assignments","Case Subtype"), testCaseDataSd.get("CASE_SUBTYPE_VERIFY").get(0), action);
		Webkeywords.instance().verifyElementDisplayed(driver, getElementBasedOnFlag(testCaseDataSd.get("ASSIGNMENT_DATE_TO_QUEUE_VERIFY").get(0),columnHeader,"Current Case Assignments","Assignment Date to Queue"), testCaseDataSd.get("ASSIGNMENT_DATE_TO_QUEUE_VERIFY").get(0), action);
		Webkeywords.instance().verifyElementDisplayed(driver, getElementBasedOnFlag(testCaseDataSd.get("SERVICE_COMPONENT_VERIFY").get(0),columnHeader,"Current Case Assignments","Service Component"), testCaseDataSd.get("SERVICE_COMPONENT_VERIFY").get(0), action);
	}
	
	public void verifyingHomeCurrentInvestigationAssignmentsFieldsHeaders(String scriptIteration, String pomIteration) {
		PageDetails action = new PageDetails();
		action.setPageActionName("verifying Current Investigation Assignments Fields");
		action.setPageActionDescription("verifying Current Investigation Assignments Fields");
		
		Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(),
					TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
				
		Webkeywords.instance().verifyElementDisplayed(driver, genericLocators.link(driver, "Current Investigation Assignments",testCaseDataSd.get("CURRENTINVESTIGATIONASSIGNMENT_VERIFY").get(0)), testCaseDataSd.get("CURRENTINVESTIGATIONASSIGNMENT_VERIFY").get(0), action);
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Folio Ref.",testCaseDataSd.get("FOLIOREF_VERIFY").get(0)), testCaseDataSd.get("FOLIOREF_VERIFY").get(0), action);
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Folio Name",testCaseDataSd.get("FOLIO_NAME").get(0)), testCaseDataSd.get("FOLIO_NAME").get(0), action);
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Folio Status",testCaseDataSd.get("FOLIO_STATUS").get(0)), testCaseDataSd.get("FOLIO_STATUS").get(0), action);
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Screening Date",testCaseDataSd.get("SCREENING_DATE").get(0)), testCaseDataSd.get("SCREENING_DATE").get(0), action);
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Response Type",testCaseDataSd.get("RESPONSE_TYPE").get(0)), testCaseDataSd.get("RESPONSE_TYPE").get(0), action);
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "F/F with Child Due Date",testCaseDataSd.get("CHILD_DUE_DATE").get(0)), testCaseDataSd.get("CHILD_DUE_DATE").get(0), action);
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Urgency",testCaseDataSd.get("URGENCY").get(0)), testCaseDataSd.get("URGENCY").get(0), action);
	}
	
	public void verifyingMyInvestigationAssignmentsFieldsHeaders(String scriptIteration, String pomIteration) {
		PageDetails action = new PageDetails();
		action.setPageActionName("verifying My Investigation Assignments Fields");
		action.setPageActionDescription("verifying My Investigation Assignments Fields");
		
		Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(),
					TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
				
		Webkeywords.instance().verifyElementDisplayed(driver, genericLocators.link(driver, "My Investigation Assignments",testCaseDataSd.get("MYINVESTIGATIONASSIGNMENT_VERIFY").get(0)), testCaseDataSd.get("MYINVESTIGATIONASSIGNMENT_VERIFY").get(0), action);
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Folio Ref.",testCaseDataSd.get("FOLIOREF_VERIFY").get(0)), testCaseDataSd.get("FOLIOREF_VERIFY").get(0), action);
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Folio Name",testCaseDataSd.get("FOLIO_NAME").get(0)), testCaseDataSd.get("FOLIO_NAME").get(0), action);
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Folio Status",testCaseDataSd.get("FOLIO_STATUS").get(0)), testCaseDataSd.get("FOLIO_STATUS").get(0), action);
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Screening Date",testCaseDataSd.get("SCREENING_DATE").get(0)), testCaseDataSd.get("SCREENING_DATE").get(0), action);
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Response Type",testCaseDataSd.get("RESPONSE_TYPE").get(0)), testCaseDataSd.get("RESPONSE_TYPE").get(0), action);
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "F/F with Child Due Date",testCaseDataSd.get("CHILD_DUE_DATE").get(0)), testCaseDataSd.get("CHILD_DUE_DATE").get(0), action);
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Closure Due Date",testCaseDataSd.get("CLOSUREDUEDATE_VERIFY").get(0)), testCaseDataSd.get("CLOSUREDUEDATE_VERIFY").get(0), action);
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Urgency",testCaseDataSd.get("URGENCY").get(0)), testCaseDataSd.get("URGENCY").get(0), action);
		
	}
	
	public void verifyingMyTeamInvestigationAssignmentsFieldsHeaders(String scriptIteration, String pomIteration) {
		PageDetails action = new PageDetails();
		action.setPageActionName("verifying My Team Investigation Assignments Fields");
		action.setPageActionDescription("verifying My team Investigation Assignments Fields");
		
		Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(),
					TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
				
		Webkeywords.instance().verifyElementDisplayed(driver, genericLocators.link(driver, "My Team’s Investigation Assignments",testCaseDataSd.get("MYTEAMINVESTIGATIONASSIGNMENT_VERIFY").get(0)), testCaseDataSd.get("MYTEAMINVESTIGATIONASSIGNMENT_VERIFY").get(0), action);			Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Folio Ref.",testCaseDataSd.get("FOLIOREF_VERIFY").get(0)), testCaseDataSd.get("FOLIOREF_VERIFY").get(0), action);
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Folio Name",testCaseDataSd.get("FOLIO_NAME").get(0)), testCaseDataSd.get("FOLIO_NAME").get(0), action);
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Folio Status",testCaseDataSd.get("FOLIO_STATUS").get(0)), testCaseDataSd.get("FOLIO_STATUS").get(0), action);
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "ER Worker Name",testCaseDataSd.get("ERWORKERNAME_VERIFY").get(0)), testCaseDataSd.get("ERWORKERNAME_VERIFY").get(0), action);
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Screening Date/Time",testCaseDataSd.get("SCREENING_DATE").get(0)), testCaseDataSd.get("SCREENING_DATE").get(0), action);
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "# of Alleged Child Victim(s)",testCaseDataSd.get("CHILDVICTIM_VERIFY").get(0)), testCaseDataSd.get("CHILDVICTIM_VERIFY").get(0), action);
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Response Type",testCaseDataSd.get("RESPONSE_TYPE").get(0)), testCaseDataSd.get("RESPONSE_TYPE").get(0), action);
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "F/F with Child Due Date",testCaseDataSd.get("CHILD_DUE_DATE").get(0)), testCaseDataSd.get("CHILD_DUE_DATE").get(0), action);
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Closure Due Date",testCaseDataSd.get("CLOSUREDUEDATE_VERIFY").get(0)), testCaseDataSd.get("CLOSUREDUEDATE_VERIFY").get(0), action);
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Urgency",testCaseDataSd.get("URGENCY").get(0)), testCaseDataSd.get("URGENCY").get(0), action);
		
	}


	public void sortCurrentInvestigationAssignments(String scriptIteration, String pomIteration) {
		PageDetails action = new PageDetails();
		action.setPageActionName("sort investigation Assignments Fields");
		action.setPageActionDescription("sort investigation Assignments Fields");
		
		Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(),
					TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
				
		Webkeywords.instance().verifyElementDisplayed(driver, genericLocators.link(driver, "Current Investigation Assignments",testCaseDataSd.get("CURRENTINVESTIGATIONASSIGNMENT_VERIFY").get(0)), testCaseDataSd.get("CURRENTINVESTIGATIONASSIGNMENT_VERIFY").get(0), action);
		Webkeywords.instance().click(driver, genericLocators.textOnPage(driver, "Folio Ref.",testCaseDataSd.get("FOLIOREF_VERIFY").get(0)), testCaseDataSd.get("FOLIOREF_VERIFY").get(0), action);
		Webkeywords.instance().click(driver, genericLocators.textOnPage(driver, "Folio Name",testCaseDataSd.get("FOLIO_NAME").get(0)), testCaseDataSd.get("FOLIO_NAME").get(0), action);
		Webkeywords.instance().click(driver, genericLocators.textOnPage(driver, "Folio Status",testCaseDataSd.get("FOLIO_STATUS").get(0)), testCaseDataSd.get("FOLIO_STATUS").get(0), action);
		Webkeywords.instance().click(driver, genericLocators.textOnPage(driver, "Screening Date",testCaseDataSd.get("SCREENING_DATE").get(0)), testCaseDataSd.get("SCREENING_DATE").get(0), action);
		Webkeywords.instance().click(driver, genericLocators.textOnPage(driver, "Response Type",testCaseDataSd.get("RESPONSE_TYPE").get(0)), testCaseDataSd.get("RESPONSE_TYPE").get(0), action);
		Webkeywords.instance().click(driver, genericLocators.textOnPage(driver, "F/F with Child Due Date",testCaseDataSd.get("CHILD_DUE_DATE").get(0)), testCaseDataSd.get("CHILD_DUE_DATE").get(0), action);
		Webkeywords.instance().click(driver, genericLocators.textOnPage(driver, "Urgency",testCaseDataSd.get("URGENCY").get(0)), testCaseDataSd.get("URGENCY").get(0), action);
	}

	public void verifyRecentRecords(String scriptIteration, String pomIteration) {
		PageDetails action = new PageDetails();
		action.setPageActionName("verifying Recent Records List");
		action.setPageActionDescription("verifying Recent Records List");
		
		Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(),
					TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
				
		Webkeywords.instance().verifyElementDisplayed(driver, recentRecords, testCaseDataSd.get("RECENTRECORDS_VERIFY").get(0), action);
		Webkeywords.instance().click(driver, genericLocators.link(driver, "View All",testCaseDataSd.get("VIEW_ALL_BTN").get(0)), testCaseDataSd.get("VIEW_ALL_BTN").get(0), action);
	}
	
	public void verifyingHomeServiceTypesFieldsHeaders ( String scriptIteration, String pomIteration){
		PageDetails action = new PageDetails();
		action.setPageActionName("verifying ServiceTypes Fields");
		action.setPageActionDescription("verifying ServiceTypes Fields");
		
			Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(),
					TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
				
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Service Types",testCaseDataSd.get("SERVICETYPES_VERIFY").get(0)), testCaseDataSd.get("SERVICETYPES_VERIFY").get(0), action);
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Service Type Name",testCaseDataSd.get("SERVICETYPENAME_VERIFY").get(0)), testCaseDataSd.get("SERVICETYPENAME_VERIFY").get(0), action);
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Service Type Description",testCaseDataSd.get("SERVICETYPEDESCRIPTION_VERIFY").get(0)), testCaseDataSd.get("SERVICETYPEDESCRIPTION_VERIFY").get(0), action);
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Service Categories",testCaseDataSd.get("SERVICECATEGORY_VERIFY").get(0)), testCaseDataSd.get("SERVICECATEGORY_VERIFY").get(0), action);
			
	}
	
	public void verifyingHomeMyTaskListFieldsHeaders ( String scriptIteration, String pomIteration) {
		PageDetails action = new PageDetails();
		action.setPageActionName("verifying MyTaskList Fields");
		action.setPageActionDescription("verifying MyTaskList Fields");
		
			Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(),
					TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
				
			Webkeywords.instance().click(driver, genericLocators.link(driver, "My Task List",testCaseDataSd.get("MYTASKLIST").get(0)),testCaseDataSd.get("MYTASKLIST").get(0), action);
			Webkeywords.instance().verifyElementDisplayed(driver, genericLocators.link(driver, "Current Task Assignments",testCaseDataSd.get("CURRENTTASKASSIGNMENT_VERIFY").get(0)), testCaseDataSd.get("CURRENTTASKASSIGNMENT_VERIFY").get(0), action);
			Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Due Date",testCaseDataSd.get("DUEDATE_VERIFY").get(0)), testCaseDataSd.get("DUEDATE_VERIFY").get(0), action);
			Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Subject",testCaseDataSd.get("SUBJECT_VERIFY").get(0)), testCaseDataSd.get("SUBJECT_VERIFY").get(0), action);
			Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Related To",testCaseDataSd.get("RELATEDTO_VERIFY").get(0)), testCaseDataSd.get("RELATEDTO_VERIFY").get(0), action);
			Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Priority",testCaseDataSd.get("PRIORITY_VERIFY").get(0)), testCaseDataSd.get("PRIORITY_VERIFY").get(0), action);
			Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Status",testCaseDataSd.get("STATUS_VERIFY").get(0)), testCaseDataSd.get("STATUS_VERIFY").get(0), action);
			Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Source",testCaseDataSd.get("SOURCE_VERIFY").get(0)), testCaseDataSd.get("SOURCE_VERIFY").get(0), action);

	}
	
	public void verifyingHomeMyOrganizationFieldsHeaders ( String scriptIteration, String pomIteration) {
		PageDetails action = new PageDetails();
		action.setPageActionName("verifying MyOrganization Fields");
		action.setPageActionDescription("verifying MyOrganization Fields");
		
		Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(),
					TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
			
		Webkeywords.instance().click(driver, genericLocators.link(driver, "My Organizations",testCaseDataSd.get("MYORGANIZATION").get(0)),testCaseDataSd.get("MYORGANIZATION").get(0), action);
		Webkeywords.instance().verifyElementDisplayed(driver, genericLocators.link(driver, "New Providers created in past 120 days",testCaseDataSd.get("NEWPROVIDER120DAYS_VERIFY").get(0)), testCaseDataSd.get("NEWPROVIDER120DAYS_VERIFY").get(0), action);
		
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Name",testCaseDataSd.get("NAME_VERIFY").get(0)), testCaseDataSd.get("NAME_VERIFY").get(0), action);
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Organization Category",testCaseDataSd.get("ORGCATEGORY_VERIFY").get(0)), testCaseDataSd.get("ORGCATEGORY_VERIFY").get(0), action);		
	}
	
	
	public void verifyingHomeMyLocationFieldsHeaders ( String scriptIteration, String pomIteration) {
		PageDetails action = new PageDetails();
		action.setPageActionName("verifying My Location Fields");
		action.setPageActionDescription("verifying My Location Fields");
		
		Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(),
				TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
			
		Webkeywords.instance().click(driver, genericLocators.link(driver, "My Locations",testCaseDataSd.get("MYLOCATION").get(0)),testCaseDataSd.get("MYORGANIZATION").get(0), action);
		Webkeywords.instance().verifyElementDisplayed(driver, genericLocators.link(driver, "New Locations created in past 120 days",testCaseDataSd.get("NEWLOCATION120DAYS_VERIFY").get(0)), testCaseDataSd.get("NEWLOCATION120DAYS_VERIFY").get(0), action);
		Webkeywords.instance().verifyTextDisplayed(driver, genericLocators.textOnPage(driver, "Location Category",testCaseDataSd.get("LOCATIONCATEGORY_VERIFY").get(0)), testCaseDataSd.get("LOCATIONCATEGORY_VERIFY").get(0), action);		
	}
	
	public void warreningMessage(){

		if (warningPopup.isDisplayed()) {
			Webkeywords.instance().jsClick(driver, warningCloseBtn);
		} else {
			logger.error("Failed at warning message");
		}
	}

	public void verifyNavigationToCurrentCase(String scriptIteration, String pomIteration){
		PageDetails action = new PageDetails();
		action.setPageActionName("Verify Navigation To Current Case");
		action.setPageActionDescription("Verify Navigation To Current Case");
		
		Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(), TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
		Webkeywords.instance().jsClick(driver, currentCaseIdLink, testCaseDataSd.get("CURRENT_CASE_LINK").get(0),action);	
		Webkeywords.instance().waitElementToBeVisible(driver,caseType);
		Webkeywords.instance().verifyElementDisplayed(driver, caseType, testCaseDataSd.get("CASE_TYPE_VERIFY").get(0), action);

	}
	
	public void verifyNavigationToCurrentTask(String scriptIteration, String pomIteration){
		PageDetails action = new PageDetails();
		action.setPageActionName("Verify Navigation To Current Task");
		action.setPageActionDescription("Verify Navigation To Current Task");
		
		Map<String, ArrayList<String>>	testCaseDataSd = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(), TestRunSettings.getTestDataMappingFileName() ,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomIteration);
		Webkeywords.instance().jsClick(driver, currentTaskIdLink, testCaseDataSd.get("CURRENT_TASK_LINK").get(0),action);	
		Webkeywords.instance().waitElementToBeVisible(driver,taskId);
		Webkeywords.instance().verifyElementDisplayed(driver, taskId, testCaseDataSd.get("TASK_ID_VERIFY").get(0), action);
		Webkeywords.instance().verifyElementDisplayed(driver, relatedTo, testCaseDataSd.get("RELATED_TO_VERIFY").get(0), action);
	}
	
	
	public WebElement getElementBasedOnFlag(String flag, String columnHeaderXpath, String tableName, String columnName) {
		if(!(flag.equalsIgnoreCase("n/a"))) {
			return driver.findElement(By.xpath(format(columnHeaderXpath,tableName,columnName)));
		}
		else
			return null;
	}

	public void clickOnNotification(String recordType, String scriptIteration, String pomiteration) {
		PageDetails action = new PageDetails();
		action.setPageActionName("Click Bell Notification Item");
		action.setPageActionDescription("Click Bell Notification Item");
		
		WebElement notificationBell = null;
		WebElement taskNotification = null;
		String recordName;
		notificationBell = Webkeywords.instance().waitAndReturnWebElement(driver,By.xpath("//button[contains(@class,'slds-global-actions__notifications slds-global-actions__item-action')]"));
		Webkeywords.instance().waitElementClickable(driver, notificationBell);
		Webkeywords.instance().click(driver, notificationBell,"", action);
		switch (recordType.toLowerCase()) {
		case "folio_id":
			recordName = SalesforceConstants.getConstantValue("RECORD_NAME");
			taskNotification = Webkeywords.instance().waitAndReturnWebElement(driver,By.xpath("//div/span[contains(text(),'" + recordName + "')]"));
			Webkeywords.instance().waitElementClickable(driver, taskNotification);
			Map<String, ArrayList<String>>	testCaseDataSd1 = util.getScreenTCData(screenName, testCaseParam.getTestNGTestMethodName(),TestRunSettings.getTestDataPath(), TestRunSettings.getTestDataMappingFileName()
					,TestRunSettings.getTestDataMappingSheetNameSd(),scriptIteration,pomiteration);
			Webkeywords.instance().click(driver, taskNotification,testCaseDataSd1.get("BELL_NOTIFICATION").get(0), action);
			Webkeywords.instance().pause();
			Webkeywords.instance().waitElementToBeVisible(driver, childNotification);
			SalesforceConstants.setConstantValue("CL_TASK_NAME", childNotification.getText());
			return;
		}
	}
	
	public void verifyCourtNotification(String expectedTitle, String expectedMessage){
		PageDetails action = new PageDetails();
		action.setPageActionName("Verify Bell Notification Message");
		action.setPageActionDescription("Verify Bell Notification Message");

		Webkeywords.instance().waitElementToBeVisible(driver, bellIcon);
		Webkeywords.instance().click(driver, bellIcon,"", action);
		Webkeywords.instance().verifyElementDisplayed(driver, driver.findElement(By.xpath(format(notificationTitle,expectedTitle))), "", action);
		Webkeywords.instance().verifyElementDisplayed(driver, driver.findElement(By.xpath(format(courtNotificationMessage,expectedMessage))), "", action);
		Webkeywords.instance().click(driver, bellIcon,"", action);
	}
	
	}