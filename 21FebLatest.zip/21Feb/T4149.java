package uitests.testng.milestone15;

import java.awt.AWTException;
import java.lang.reflect.Method;
import java.util.Objects;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import cares.cwds.salesforce.constants.SalesforceConstants;
import cares.cwds.salesforce.pom.Home;
import cares.cwds.salesforce.pom.Login;
import cares.cwds.salesforce.pom.courts.CourtCase;
import cares.cwds.salesforce.pom.courts.CourtHearings;
import cares.cwds.salesforce.pom.courts.CourtMinuteOrder;
import cares.cwds.salesforce.pom.courts.CourtOfficerNotes;
import cares.cwds.salesforce.pom.courts.CourtReports;
import cares.cwds.salesforce.pom.courts.CourtWorkItems;
import cares.cwds.salesforce.pom.courts.DocumentDistributions;
import cares.cwds.salesforce.pom.courts.Participants;
import cares.cwds.salesforce.pom.courts.Related;
import cares.cwds.salesforce.pom.referral.Person;
import cares.cwds.salesforce.pom.referral.ReleasesOfInformationAndConsentForm;
import cares.cwds.salesforce.pom.referralcase.CaseReferralPersons;
import cares.cwds.salesforce.pom.referralcase.placement.ChildLocations;
import cares.cwds.salesforce.pom.referralcase.placement.LegalAuthority;
import cares.cwds.salesforce.pom.referralcase.placement.Placement;
import cares.cwds.salesforce.pom.referralcase.placement.ProviderSearch;
import cares.cwds.salesforce.pom.referralcase.placement.Removal;
import cares.cwds.salesforce.utilities.testng.TestNGCommon;
import cares.cwds.salesforce.utilities.testng.TestNGListener;
import cares.cwds.salesforce.utilities.web.SalesforceCommon;
import uitests.testng.datasetup.CaseDataSetup1;

@Listeners(TestNGListener.class)
public class T4149  extends TestNGCommon{
	String testCaseName = "T4149 Test Case";
	String moduleName = "cares";
	String fileName = "ScriptMasterSheet"; 
	private static final String Petition_Message ="Findings and Orders/Minute Orders have been received for petition"; 
	private static final String Jurisdiction_Message ="Findings and Orders/Minute Orders have been received for terminated jurisdiction"; 

	@BeforeMethod
	public void setUpReport()
	{
		setTestAttributes("testCaseParam",testCaseParam);
	}

	@Test (dataProvider = "data-provider",priority = 1, enabled = true)
	public void testT4149(String scriptIteration) throws AWTException, InterruptedException{
		driver = (WebDriver) getTestAttribute("driver");

		/** PreReq Data ***/
//		//Read Investigative Case record from datasheet
//		SalesforceConstants.setConstantValue("CASE_ID1", readOutputSheet("Case", false, "Contra"));
//
//		//PreData Setup scenario
//		//Running preData setup scenario if case record is null from output data sheet
//		if(Objects.isNull(SalesforceConstants.getConstantValue("CASE_ID1")) ){
//			CaseDataSetup1 caseDataSetup = new CaseDataSetup1();
//			caseDataSetup.testCaseDataSetup1("1");
//		}

		///////////////////////// Login As CM Worker County 1/////////////////////////////////////////////////////

		//Step 1
		Login login = new Login(driver);
		login.processLoginNew( scriptIteration,SalesforceConstants.POMITERATION1, SalesforceConstants.LOGINUSER); 

		//Step 2
		Home home = new Home(driver);
		home.closeAllTabs();
		//home.navigateToAppMenuPage("CARES Items", scriptIteration, SalesforceConstants.POMITERATION1);

		//Pre request
		
		//add 1 person , 1 legal guarding
//		Person folioPerson = new Person(driver);
//		SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.CASEURL);
//		SalesforceCommon.scrollDown(driver);
//		folioPerson.navigateToFolioPersonsTab( scriptIteration, SalesforceConstants.POMITERATION1);
//	    folioPerson.addFolioPerson( scriptIteration, SalesforceConstants.POMITERATION1);
//	    SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.CASEURL);
//	
//		CaseReferralPersons caseReferralPersons = new CaseReferralPersons(driver);
//		caseReferralPersons.navigateToCaseFolioPersons(scriptIteration, SalesforceConstants.POMITERATION1);
//    	caseReferralPersons.getCaseFolioPersonDetails();
//    	String victim= SalesforceConstants.getObjectValue("CASE_PERSON_MAP").get("Victim1")[1];
  
		
		ProviderSearch providerSearch = new ProviderSearch(driver);
//		providerSearch.navigateToProviderSearch(scriptIteration,SalesforceConstants.POMITERATION1);
//		providerSearch.searchProvderType(scriptIteration,SalesforceConstants.POMITERATION1);
//		providerSearch.enterNewPlacementDetails(scriptIteration,SalesforceConstants.POMITERATION1);
//
//		SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.CASEURL);
		Placement placement = new Placement(driver);
//		placement.navigateToPlacement(scriptIteration, SalesforceConstants.POMITERATION1);
//
		Removal removal = new Removal(driver);
//		removal.navigateToRemovalTab(scriptIteration, SalesforceConstants.POMITERATION1);
//		removal.navigateToRemovalRecord(scriptIteration, SalesforceConstants.POMITERATION1);
//
//		SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.CASEURL);			
//		placement= new Placement(driver);
//		placement.navigateToPlacement(scriptIteration, SalesforceConstants.POMITERATION1);
//
		ChildLocations childLocations = new ChildLocations(driver);
//		childLocations.clickNewChildLocationType(scriptIteration, SalesforceConstants.POMITERATION1);
//		childLocations.enterChildLocationPlacementDetails(scriptIteration, SalesforceConstants.POMITERATION1);

		// CAS-000001534815
		// FOL-000001534815
		home.searchFolioRecord(scriptIteration, scriptIteration);
		
		//Step 3
//		CourtCase courtCase = new CourtCase(driver);
//		courtCase.navigateToCourtCase(scriptIteration, SalesforceConstants.POMITERATION1);

//		//Step 4
//		courtCase.courtCaseInformation(scriptIteration, SalesforceConstants.POMITERATION1);

//		//Step 5
//		SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.CASEURL);

//		//Step 6
//		courtCase.navigateToCourtCase(scriptIteration, SalesforceConstants.POMITERATION1);

//		//Step 7
//		courtCase.navigateToCourtCaseRecord(scriptIteration, SalesforceConstants.POMITERATION2);
//		SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.CASEURL);
//
//		//Step 8
		CourtWorkItems courtWorkItem = new CourtWorkItems(driver);
//		courtWorkItem.navigateToCourtWorkItems(scriptIteration, SalesforceConstants.POMITERATION1);
		
//		//Step 9 
//		courtWorkItem.verifyCourtWorkItemsRelatedList(scriptIteration, SalesforceConstants.POMITERATION1);

//		//Step 10 and 11
//		//courtWorkItem = new CourtWorkItems(driver);
//		//courtWorkItem.navigateToCourtWorkItems(scriptIteration, SalesforceConstants.POMITERATION1);
			
		CourtHearings hearing = new CourtHearings(driver);
//		hearing.enterHearingDetails(scriptIteration, SalesforceConstants.POMITERATION1);

		SalesforceConstants.setConstantValue("HEARING_ID1","CWI-000000549820");//temp

		//Step 12,13,14
		Participants participants = new Participants(driver);
//		participants.navigateToParticipants(scriptIteration, SalesforceConstants.POMITERATION1);
//		participants.verifyParticipantsRelatedList(scriptIteration, SalesforceConstants.POMITERATION2);

		//Step 15,16
//		participants.addFocusChild(scriptIteration, SalesforceConstants.POMITERATION2);
		SalesforceConstants.getCurrentPageUrl(driver,"HEARINGCOURTWORKITEM");//temp
		
		//step 17 
//		participants.navigateToParticipants(scriptIteration, SalesforceConstants.POMITERATION1);
//		participants.verifyHeaderColumnsInParticipantsForChildren(scriptIteration, SalesforceConstants.POMITERATION2);

		//step 18 
//		participants.addPickParticipant(scriptIteration, SalesforceConstants.POMITERATION2);
		
		//step 19
//		participants.verifyHeaderColumnsInParticipantsForWorkItem(scriptIteration, SalesforceConstants.POMITERATION2);
//		SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.CASEURL);

		//step 20
//		courtWorkItem = new CourtWorkItems(driver);
//		courtWorkItem.navigateToCourtWorkItems(scriptIteration, SalesforceConstants.POMITERATION1);
		
//		hearing = new CourtHearings(driver);
//		hearing.navigateToHearingRecord(scriptIteration, SalesforceConstants.POMITERATION1);
		
		//Step 21 click hearing details tab
//		hearing.verifySectionsInHearingDetails(scriptIteration, SalesforceConstants.POMITERATION1);

		//Step 22 
		CourtMinuteOrder courtMinuteOrder = new CourtMinuteOrder(driver);
//		courtMinuteOrder.navigateToCourtMinuteOrder(scriptIteration, SalesforceConstants.POMITERATION1);
//		courtMinuteOrder.validateNewBtn();

		//Step 23 
		hearing = new CourtHearings(driver);
//		hearing.navigateToHearingDetailTab(scriptIteration, SalesforceConstants.POMITERATION2);

		//step 24,25,26,27,28,29 for concent
//		hearing.editHearingRecord(scriptIteration, SalesforceConstants.POMITERATION2);

		//Step 30,31,32 for continued
//		hearing.editHearingRecord(scriptIteration, SalesforceConstants.POMITERATION3);

		//Step 33
		courtMinuteOrder = new CourtMinuteOrder(driver);
//		courtMinuteOrder.navigateToCourtMinuteOrder(scriptIteration, SalesforceConstants.POMITERATION1);
//		courtMinuteOrder.validateNewBtn();

		// Step 34 click new btn and validate fields
//		courtMinuteOrder.navigateToCourtMinuteOrderPage(scriptIteration, SalesforceConstants.POMITERATION1);

		// Step 35 fill mandate data and save
//		courtMinuteOrder.addCourtMinuteOrderPageInformation(scriptIteration, SalesforceConstants.POMITERATION1);

		// Step 36 verify notification- existing defect 
//		home = new Home(driver);
//		home.verifyCourtNotification(Petition_Message, Petition_Message + " for" + " petition" + "" + " for following children that is available on" + " for :" +" Add Person name");

		// Step 37 navigate to court minute order  step not required
		//courtMinuteOrder.navigateToCourtMinuteOrderPage(scriptIteration, SalesforceConstants.POMITERATION1);

		//step 38,39,40 click record id and edit and save
		courtMinuteOrder.navigateToExistingCourtMinuteOrderRecord(scriptIteration, SalesforceConstants.POMITERATION1);
		courtMinuteOrder.addCourtMinuteOrderPageInformation(scriptIteration, SalesforceConstants.POMITERATION1);

		//Step 41 verify notification for Juriction- existing defect
		//home = new Home(driver);
		//home.verifyCourtNotification(Jurisdiction_Message, Jurisdiction_Message + " for" + " petition" + "" + " for following children that is available on" + " for :" +" Add Person name");

		// Step 41-43
		SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.CASEURL);
		placement = new Placement(driver);
		placement.navigateToPlacement(scriptIteration, SalesforceConstants.POMITERATION1);

		removal = new Removal(driver);
		removal.navigateToRemovalTab(scriptIteration, SalesforceConstants.POMITERATION1);
		removal.navigateToRemovalRecord(scriptIteration, SalesforceConstants.POMITERATION1);

		LegalAuthority legalAuthority = new LegalAuthority(driver);
		legalAuthority.navigateToLegalAuthorityTab(scriptIteration,SalesforceConstants.POMITERATION1);
		legalAuthority.clickNewLegalAuthority(scriptIteration,SalesforceConstants.POMITERATION1);
		legalAuthority.addLegalInfo(scriptIteration,SalesforceConstants.POMITERATION1);
		legalAuthority.verifyingLegalAuthorityHeaders(scriptIteration,SalesforceConstants.POMITERATION1);

		//Step 44
		legalAuthority.clickNewLegalAuthority(scriptIteration,SalesforceConstants.POMITERATION1);
		legalAuthority.addLegalInfo(scriptIteration,SalesforceConstants.POMITERATION1);

		//Step 45-46
		SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.HEARINGCOURTWORKITEMURL);
		courtMinuteOrder = new CourtMinuteOrder(driver);
		courtMinuteOrder.navigateToCourtMinuteOrder(scriptIteration,SalesforceConstants.POMITERATION2);
		courtMinuteOrder.navigateToExistingCourtMinuteOrderRecord(scriptIteration,SalesforceConstants.POMITERATION2);
		courtMinuteOrder.addCourtMinuteOrderPageInformation(scriptIteration,SalesforceConstants.POMITERATION2);

		//Step 48
		Related related = new Related(driver);
		related.navigateToRelatedTab(scriptIteration,SalesforceConstants.POMITERATION1);
		related.navigateToExistingRelatedFolioRecord(scriptIteration,SalesforceConstants.POMITERATION1);

		//Steps 49-50
		SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.CASEURL);			
		placement= new Placement(driver);
		placement.navigateToPlacement(scriptIteration, SalesforceConstants.POMITERATION1);

		childLocations = new ChildLocations(driver);
		childLocations.clickNewChildLocationType(scriptIteration, SalesforceConstants.POMITERATION2);
		childLocations.navigateToChildLocationRecord(scriptIteration, SalesforceConstants.POMITERATION2);
		childLocations.editChildLocationPlacementDetails(scriptIteration, SalesforceConstants.POMITERATION2);

		//Steps 51- 52- 53 - Need more Clarity on the functionality and the steps to reproduce it.

		//Step 54
		SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.HEARINGCOURTWORKITEMURL);
		CourtWorkItems courtWorkItems = new CourtWorkItems(driver);
		courtWorkItems.navigateToCourtWorkItems(scriptIteration, SalesforceConstants.POMITERATION2);

		//Step 55
		hearing = new CourtHearings(driver);
		hearing.navigateToHearingRecord(scriptIteration, SalesforceConstants.POMITERATION4);

		//Step 56-57
		CourtOfficerNotes courtOfficerNotes = new CourtOfficerNotes(driver);
		courtOfficerNotes.navigateToCourtOfficerNotes(scriptIteration, SalesforceConstants.POMITERATION1);
		courtOfficerNotes.addCourtOfficerNotesPageDetails(scriptIteration, SalesforceConstants.POMITERATION1);

		//Step 58-62-63-64-65-66 
        DocumentDistributions documentDistributions = new DocumentDistributions(driver);
        documentDistributions.navigateToDocumentDistributions(scriptIteration, SalesforceConstants.POMITERATION1);
        documentDistributions.navigateToDocumentDistributionPage(scriptIteration, SalesforceConstants.POMITERATION1);
        documentDistributions.addDistributionType(scriptIteration, SalesforceConstants.POMITERATION1);
        documentDistributions.addCourtDocumentsInformation(scriptIteration, SalesforceConstants.POMITERATION1);
        documentDistributions.addNoticeInformation(scriptIteration, SalesforceConstants.POMITERATION1);
        
      //Step 67
        SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.HEARINGCOURTWORKITEMURL);

        documentDistributions.navigateToDocumentDistributions(scriptIteration, SalesforceConstants.POMITERATION1);
        documentDistributions.navigateToNoticeRecord(scriptIteration, SalesforceConstants.POMITERATION1);
        documentDistributions.VerfiyNoticeRecord(scriptIteration, SalesforceConstants.POMITERATION1);
     
        //Step 68  
        SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.HEARINGCOURTWORKITEMURL);

        documentDistributions.navigateToDocumentDistributions(scriptIteration, SalesforceConstants.POMITERATION1);
        documentDistributions.navigateToDocumentDistributionPage(scriptIteration, SalesforceConstants.POMITERATION1);
        documentDistributions.addDistributionType(scriptIteration, SalesforceConstants.POMITERATION1);
        documentDistributions.addNoticeInformation(scriptIteration, SalesforceConstants.POMITERATION1);
          
        SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.HEARINGCOURTWORKITEMURL);

        documentDistributions.navigateToNoticeRecord(scriptIteration, SalesforceConstants.POMITERATION1);
        documentDistributions.VerfiyNoticeRecord(scriptIteration, SalesforceConstants.POMITERATION1);
     
        //Step 69  
        SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.HEARINGCOURTWORKITEMURL);

        documentDistributions.navigateToDocumentDistributions(scriptIteration, SalesforceConstants.POMITERATION1);
        documentDistributions.navigateToDocumentDistributionPage(scriptIteration, SalesforceConstants.POMITERATION1);
        documentDistributions.addDistributionType(scriptIteration, SalesforceConstants.POMITERATION1);
        documentDistributions.addNoticeInformation(scriptIteration, SalesforceConstants.POMITERATION1);
          
        SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.HEARINGCOURTWORKITEMURL);

        documentDistributions.navigateToNoticeRecord(scriptIteration, SalesforceConstants.POMITERATION1);
        documentDistributions.VerfiyNoticeRecord(scriptIteration, SalesforceConstants.POMITERATION1);
        
        //Step 70 
        SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.HEARINGCOURTWORKITEMURL);

        documentDistributions.navigateToDocumentDistributions(scriptIteration, SalesforceConstants.POMITERATION1);
        documentDistributions.navigateToDocumentDistributionPage(scriptIteration, SalesforceConstants.POMITERATION1);
        documentDistributions.addDistributionType(scriptIteration, SalesforceConstants.POMITERATION1);
        documentDistributions.addNoticeInformation(scriptIteration, SalesforceConstants.POMITERATION1);
          
        SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.HEARINGCOURTWORKITEMURL);

        documentDistributions.navigateToNoticeRecord(scriptIteration, SalesforceConstants.POMITERATION1);
        documentDistributions.VerfiyNoticeRecord(scriptIteration, SalesforceConstants.POMITERATION1);
        
      //Step 71
        hearing = new CourtHearings(driver);
        SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.HEARINGCOURTWORKITEMURL);

        hearing.verifySectionsInHearingDetails(scriptIteration, SalesforceConstants.POMITERATION1);
        
      //Step 72-75
        SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.HEARINGCOURTWORKITEMURL);

        CourtReports courtReports = new CourtReports(driver);
        courtReports.navigateToCourtReports(scriptIteration, SalesforceConstants.POMITERATION1);
        courtReports.addCourtReportPageInformation(scriptIteration, SalesforceConstants.POMITERATION1);
      //Step 76-79
        SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.CASEURL);
        ReleasesOfInformationAndConsentForm releasesOfInformationAndConsentForm = new ReleasesOfInformationAndConsentForm(driver);
        releasesOfInformationAndConsentForm.navigateToReleaseOfInformationAndConsentForm(scriptIteration, SalesforceConstants.POMITERATION1);
        releasesOfInformationAndConsentForm.addReleaseOfInformationAndConsentFormDetails(scriptIteration, SalesforceConstants.POMITERATION1); 
       
        SalesforceCommon.navigateToRecordURL(driver, SalesforceConstants.CASEURL);
        releasesOfInformationAndConsentForm.navigateToReleaseOfInformationAndConsentForm(scriptIteration, SalesforceConstants.POMITERATION1);
        releasesOfInformationAndConsentForm.navigateToReleaseInformationAndConsentFormRecord(scriptIteration, SalesforceConstants.POMITERATION1);
        releasesOfInformationAndConsentForm.VerfiyReleaseInformationAndConsentForm(scriptIteration, SalesforceConstants.POMITERATION1);
	}
	
	 @DataProvider (name = "data-provider")
	    public String[] dpMethod(Method method){
		 testCaseParam.setTestCaseName(testCaseName);
	        testCaseParam.setModuleName(moduleName);
	        testCaseParam.setBrowser(browser);
	        testCaseParam.setTestCaseDescription(testCaseParam.getTestCaseName());
	        testCaseParam.setTestCaseDescription(testCaseParam.getTestCaseName());
	        testCaseParam.setTestNGTestMethodName(method.getName());
	    	return setScriptIterationFlag(fileName,moduleName, method.getName());
	   
	    }

}
